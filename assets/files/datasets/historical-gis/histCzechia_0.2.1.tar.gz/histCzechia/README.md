# histCzechia

An R interface to historical Czech district research data. Package **0.2.1**
reads the public research edition **v0.6.1** and the earlier **v0.5/v0.6**
releases. Queries open a local GeoPackage read-only. The main geography is
330 judicial districts of 1930; judicial 1921 and political 1921/1930
geographies are also available. The territorial coverage is the Czech lands.

## Download, install and connect

```r
install.packages(c("sf", "DBI", "RSQLite", "digest"))
base <- "https://adamdittrich.github.io/assets/files/datasets/historical-gis/"
download.file(paste0(base, "histCzechia_0.2.1.tar.gz"),
              "histCzechia_0.2.1.tar.gz", mode = "wb")
install.packages("histCzechia_0.2.1.tar.gz", repos = NULL, type = "source")
download.file(paste0(base, "GIS_Czech_Lands_Public_v0_6_1.zip"),
              "GIS_Czech_Lands_Public_v0_6_1.zip", mode = "wb")

library(histCzechia)
hc_use("GIS_Czech_Lands_Public_v0_6_1.zip",
       cache_dir = tools::R_user_dir("histCzechia", "data"))
hc_data_status()
```

An extracted directory or the exact `historical_gis_czech_lands_v061.gpkg`
file also works. `hc_use()` verifies SHA-256 against the versioned release
catalogue by default and checks the district keys. A ZIP or directory must
contain exactly one recognised integrated GeoPackage. The public archive
contains derived district outputs and documentation, with links to the
original data providers.

No account is required. The package itself does not download data implicitly;
queries after setup work offline. Without an explicit `cache_dir`, ZIP
extraction lasts for the R session. Run `hc_use()` in each session, or set
`HISTCZECHIA_DATA` to an existing GeoPackage. The package is not on CRAN.
Its own code is pure R; `sf` has the usual GDAL/GEOS/PROJ requirements on Linux.

The original releases remain supported with their original pinned hashes:

```r
# hc_use("historical_gis_czech_lands_v06.gpkg")
# hc_use("historical_gis_czech_lands_v05.gpkg")
```

## Semily

```r
semily <- hc_districts(district = "Semily")
semily[c("NAZEV", "population", "mean_elevation_m", "river_length_km")]
# Census 1930: 17749 people; modern mean elevation: 463.9597 m;
# represented HydroRIVERS route length inside the district: 31.4020 km.

weather <- hc_climate(1930, district = "Semily")
weather[c("calendar_year", "temp_mean_c", "precip_mm")]
# 1930; 6.850685 degrees C; 1032.300 mm.

rail <- hc_railways(1930, district = "Semily")
rail[c("calendar_year", "rail_operating_length_km",
       "rail_operating_density_km_per_100km2")]
# 1930; 11.81179 km; 13.06240 km per 100 km2.

hc_soil(district = "Semily")
hc_landuse(c(1845, 1948), district = "Semily")
hc_minerals(district = "Semily")
hc_basins(district = "Semily", basin_level = c(6, 8, 12))
hc_geology(district = "Semily", detail = "composition")
hc_borders(district = "Semily", dates = "1938-10-01")
hc_neighbors(district = "Semily")
hc_gazetteer(district = "Semily", detail = "summary")
hc_quality_flags(district = "Semily")

profile <- hc_profile("Semily", climate_years = 1930)
names(profile)
```

These values come from the supplied research data. The executable example
in `inst/examples/semily.R` exports thematic tables and a district/climate
figure. It runs with the public edition; optional upstream river/rail lines
are plotted only when the connected older release actually contains them.

## 444 core fields and 18 climate-normal fields

The original main v0.6 master has 462 fields. In the public v0.6.1 collection,
`hc_districts()` returns the 444 core fields, with geometry when requested.
The same 18 climate-normal fields are accessible through
`hc_climate_normals()`. This keeps the CRU-derived climate component and its
ODbL conditions explicit. The split loses no original normal values.

```r
core <- hc_districts(geometry = FALSE)
normals <- hc_climate_normals()
fields <- grep("^clim_normal", names(normals), value = TRUE)
idx <- match(core$district_year_id, normals$district_year_id)
stopifnot(length(fields) == 18L, !anyNA(idx),
          !anyDuplicated(normals$district_year_id))
combined <- cbind(core, normals[idx, fields, drop = FALSE])
# 330 rows, 462 original fields; inspect component terms before redistribution.
```

Field count includes identifiers, diagnostics and alternative definitions.
It is not a count of independent complete historical measurements. Every
variable retains its own observation period, denominator and coverage.
`hc_panel()` explicitly joins annual climate, the static core and year-specific
railway states for analysis; a repeated census value remains static.

## Functions and release compatibility

| Function | Output | Availability |
|---|---|---|
| `hc_districts()` | Static district master; polygons by default | All releases; climate normals separate in public v0.6.1 |
| `hc_find_district()` | Names and stable IDs | All releases |
| `hc_census()`, `hc_terrain()`, `hc_elections()` | Source thematic fields and inherited flags | All releases |
| `hc_climate()` | Monthly/annual district climate, 1901–1938 | All releases |
| `hc_climate_normals()`, `hc_cru_weights()` | 1901–1928 reference means and grid weights | All releases |
| `hc_hydro()` | Derived river indicators | All releases |
| `hc_panel()` | Annual climate + static master + available yearly railway state | All releases |
| `hc_railways()` | Year-specific railway indicators | v0.6 and public v0.6.1 |
| `hc_soil(detail="summary"/"depth")` | Modern modelled soil properties and depth intervals | v0.6 and public v0.6.1 |
| `hc_landuse(years=c(1845,1948,1990,2000))` | Area-allocated land-use estimates | v0.6 and public v0.6.1 |
| `hc_minerals()` | Contemporary inventory summaries, categories and links | v0.6 and public v0.6.1 |
| `hc_basins(detail="summary"/"links")` | Catchment membership and intersections | v0.6 and public v0.6.1 |
| `hc_geology(detail="summary"/"composition")` | Geological summaries and map categories | v0.6 and public v0.6.1 |
| `hc_borders()` | Five dated state-border snapshots | v0.6 and public v0.6.1 |
| `hc_neighbors()`, `hc_district_distances()` | Directed spatial relations | v0.6 and public v0.6.1 |
| `hc_gazetteer(detail="summary")` | Multitemporal locality reference counts | v0.6 and public v0.6.1 |
| `hc_quality_flags()` | Publication qualifications and correction notes | Public v0.6.1 |
| `hc_profile()` | Named thematic tables available in the connected edition | All releases |
| `hc_dictionary()`, `hc_sources()`, `hc_source_files()` | Definitions, periods, attribution and file hashes | Dictionary/source summary also available offline |
| `hc_data_status()`, `hc_validate_data()` | Connection, SHA-256 and structural checks | All releases |

`hc_rivers()`, `hc_rail_network()` and
`hc_gazetteer(detail="localities")` require their respective optional upstream
geometry tables. These tables are omitted from the public research edition.
The accessors explain the provider and available district-summary alternative.
They still work with earlier releases that include the source geometries.

Most district accessors accept `boundary_year=1921` or `1930`,
`level="judicial"` or `"political"`, and `district=NULL` for all districts.
Names match exactly, ignoring case and Czech accents; ambiguous names fail.
Use stable IDs such as `"CZ1930-J-30102"` for joins. The extension accessors
return `data.frame` by default; `geometry=TRUE` attaches district polygons.

Boundary year and observation year are separate. For example,
`hc_railways(1935, boundary_year=1921, district="Semily")` uses 1935 railway
states on 1921 boundaries. `hc_borders()` accepts exactly the five supplied
dates: 1921-01-01, 1930-01-01, 1938-09-29, 1938-10-01 and 1938-12-31.
The three 1938 snapshots are never collapsed into one annual observation.

## Publication qualifications and scientific interpretation

```r
hc_quality_flags(district = c("CZ1930-J-30247", "CZ1930-J-30245"),
                 module = "elections")
hc_quality_flags(district = "CZ1930-J-30294", module = "rail")
hc_profile("Semily")$notes
```

The public flags identify affected modules and years. Original census and
inherited election values are preserved; the R accessors do not silently
mask them. The absence of a flag is not proof of archival verification.

- Brno judicial census units and municipal election units need a territorial
  crosswalk. The valid judicial population must not be replaced by the
  municipality's population. Other election and economic outliers retain
  their specific qualification notes.
- Public v0.6.1 corrects the opening of Horní Lideč–Púchov from source year
  1928 to verified 1937, with complete affected-year rail recomputation.
  Missing Poříčany–Nymburk geometry remains flagged. Distances are to tracks,
  not stations, and a source limited to Czechia can omit nearer foreign lines.
- CRU's 0.5-degree grid covers these 330 districts with 60 cells; Semily uses
  one cell. Area weighting creates no finer weather measurements. The project
  reference period 1901–1928 is not a standard 30-year WMO normal.
- HydroRIVERS topology is modern; discharge represents modelled 1971–2000
  means. Terrain, soils and catchments are modern environmental controls.
- LUCC contains 1845, 1948, 1990 and 2000 area allocations, with coverage
  diagnostics. No 1930 value or exact within-unit forest location is inferred.
- Mineral inventory was retrieved on 2026-11-03. It does not identify mines
  operating in 1930 or historical production and employment.
- CShapes is a generalised complete-state model, unsuitable for precise
  annexed-population calculations. CZ_RETRO is a multitemporal reference,
  not a list of settlements confirmed to exist in 1930.
- Geological summaries keep ambiguous overlap/coverage explicit. Spatial
  neighbour weights refer to the complete geography and are not renormalised
  after selecting a subset. Census definitions and political/1921 age
  reconstruction limitations remain in the methods and inherited flags.

## Checks and source terms

```sh
R CMD build histCzechia
HISTCZECHIA_TEST_PUBLIC_DATA=/path/to/historical_gis_czech_lands_v061.gpkg \
HISTCZECHIA_TEST_DATA=/path/to/historical_gis_czech_lands_v06.gpkg \
HISTCZECHIA_TEST_V05=/path/to/historical_gis_czech_lands_v05.gpkg \
  R CMD check --no-manual histCzechia_0.2.1.tar.gz
```

Tests with real data opt in through these paths and never download or modify
observations. Ordinary checks cover metadata and input validation.

The R code is MIT licensed. Data form a collection of independently sourced
components with their own conditions. CRU climate is ODbL 1.0 plus Database
Contents License; CShapes is CC BY-NC-SA 4.0; LUCC has academic/study-use
conditions; HydroSHEDS and Copernicus use their own notices. CZ_RETRO's
specific NPÚ service metadata says CC BY-SA 4.0, while its SOVAMM author page
says CC BY-NC-SA 4.0; the source notes preserve that conflict. The package does
not grant a new licence to the UPOL railway or selected ČGS source databases.
Original provider geometry is linked upstream in the public edition.

See `README_CZ.md`, the installed `doc/METHODS_CZ.md` and
`doc/DATA_SOURCES.md`, `hc_sources()`, and the public release's component
licensing manifest. A local join for analysis does not remove source terms
when redistributing a combined database.
