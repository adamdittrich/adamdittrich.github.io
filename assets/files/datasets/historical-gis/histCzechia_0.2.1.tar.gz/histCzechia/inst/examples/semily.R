# Run after installing histCzechia.
# CLI: Rscript semily.R /path/to/release.zip /path/to/output-directory
# Interactive: source(system.file('examples', 'semily.R', package='histCzechia'))

library(histCzechia)
args <- commandArgs(trailingOnly = TRUE)
if (length(args) >= 1L) {
  hc_use(args[[1L]])
} else if (!hc_data_status()$configured) {
  hc_use(file.choose())
}
output_dir <- if (length(args) >= 2L) args[[2L]] else tempdir()
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

semily <- hc_districts(district = "Semily", crs = 3035)
annual <- hc_climate(district = "Semily")
tables <- hc_data_status()$available_tables
rivers <- if ("hydrorivers_source_region" %in% tables)
  hc_rivers("Semily", crs = 3035) else NULL
census <- hc_census(district = "Semily")
profile <- hc_profile("Semily")
rail <- NULL
if ("rail_source_upol" %in% tables) {
  source_lines <- hc_rail_network(1930, crs = 3035)
  local_lines <- source_lines[lengths(sf::st_intersects(source_lines, semily)) > 0, ]
  rail <- suppressWarnings(sf::st_intersection(local_lines, semily["district_year_id"]))
}
for (name in intersect(c("railways", "soil", "soil_by_depth", "landuse", "basins",
                        "basin_links", "geology", "geology_composition", "minerals",
                        "mineral_categories", "borders", "neighbors", "gazetteer",
                        "gazetteer_summary", "climate_normals", "quality_flags"), names(profile))) {
  utils::write.csv(profile[[name]], file.path(output_dir, paste0("semily_", name, ".csv")),
                   row.names = FALSE, fileEncoding = "UTF-8")
}

print(sf::st_drop_geometry(semily)[c("NAZEV", "population", "mean_elevation_m", "river_length_km")])
print(annual[annual$calendar_year == 1930, c("calendar_year", "temp_mean_c", "precip_mm")])

utils::write.csv(census, file.path(output_dir, "semily_census_1930.csv"),
                 row.names = FALSE, fileEncoding = "UTF-8")
utils::write.csv(annual, file.path(output_dir, "semily_climate_1901_1938.csv"),
                 row.names = FALSE, fileEncoding = "UTF-8")

grDevices::png(file.path(output_dir, "semily_histCzechia_demo.png"),
               width = 1800, height = 1000, res = 150)
old <- graphics::par(mfrow = c(1, 2), mar = c(4.2, 4.2, 4.5, 1.4),
                     oma = c(3, 0, 1, 0), family = "sans", col.axis = "#45515c")
plot(sf::st_geometry(semily), col = "#edf2f5", border = "#273c4c", lwd = 1.5,
     axes = FALSE, main = "SEMILY | Judicial district, 1930")
if (!is.null(rivers)) plot(sf::st_geometry(rivers), col = "#087eab", lwd = 2, add = TRUE)
if (!is.null(rail)) plot(sf::st_geometry(rail), col = "#a9442b", lwd = 2.2, add = TRUE)
labels <- "Historical boundary"
colors <- "#273c4c"
widths <- 1.5
if (!is.null(rivers)) {
  labels <- c(labels, "HydroRIVERS network")
  colors <- c(colors, "#087eab")
  widths <- c(widths, 2)
}
if (!is.null(rail)) {
  labels <- c(labels, "Reconstructed railway state, 1930")
  colors <- c(colors, "#a9442b")
  widths <- c(widths, 2.2)
}
graphics::legend("bottomleft", legend = labels, col = colors,
                 lwd = widths, bty = "n", cex = 0.75)
graphics::plot(annual$calendar_year, annual$temp_mean_c, type = "l", lwd = 2,
               col = "#ca5733", xlab = "Calendar year", ylab = "Annual mean temperature (C)",
               main = "CRU-TS | Annual climate, 1901-1938")
normal <- mean(annual$temp_mean_c[annual$calendar_year <= 1928])
graphics::abline(h = normal, lty = 2, col = "#536471")
graphics::points(1930, annual$temp_mean_c[annual$calendar_year == 1930],
                 pch = 19, col = "#273c4c", cex = 1.1)
graphics::legend("topleft", legend = c("Annual mean", "1901-1928 mean", "1930"),
                 col = c("#ca5733", "#536471", "#273c4c"),
                 lty = c(1, 2, NA), pch = c(NA, NA, 19), bty = "n", cex = 0.85)
graphics::mtext(paste0("histCzechia ", utils::packageVersion("histCzechia"),
                         " | Data release ", hc_data_status()$data_version,
                         " | Semily climate comes from one 0.5-degree CRU cell."),
                side = 1, outer = TRUE, line = 1, cex = 0.8, col = "#536471")
graphics::par(old)
grDevices::dev.off()
message("Example outputs: ", normalizePath(output_dir))
