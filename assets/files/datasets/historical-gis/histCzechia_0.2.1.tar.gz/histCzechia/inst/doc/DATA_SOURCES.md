# Data sources, attribution and component licences

This document accompanies `histCzechia` and the separately supplied historical
GIS datasets **v0.5, v0.6 and public v0.6.1**. Source information was checked on **4 November 2026**.

## Software and data are separate

The package's original R code is covered by its MIT licence. That licence does
**not** relicense the historical, climate, elevation, hydrological or electoral
data accessed by the package. Each component retains its original attribution,
licence and interpretive conditions.

The package reads local data through `hc_use()`. Large research data remain
external to the R source package. Public v0.6.1 is a collection of separately
attributed analytical components with four historical district geometries.
Original upstream networks and point/polygon collections are linked at their
providers. The public GeoPackage separates climate tables from the core
master; the 18 original climate-normal fields remain accessible through
`hc_climate_normals()`. A source database's availability for download does
not establish a blanket redistribution licence. The package is not on CRAN.

The dataset's `docs/SOURCES_AND_LICENSES.md`, `docs/METHODS_CZ.md`, source
manifests and archived provider documents remain the detailed provenance
record. Consult `hc_sources()` for the package's source catalogue.

## Historical boundaries and census data

Provider: **Urbánní a regionální laboratoř (URRlab), Faculty of Science,
Charles University**, NAKI project **DF12P01OVV033**.

Citation:

Jíchová, J., Soukup, M., Nemeškal, J., Ouředníček, M., Pospíšilová, L.,
Svoboda, P., Špačková, P. and collaborators (2014). *Geodatabáze historických
statistických a prostorových dat Česka ze Sčítání lidu, domů a bytů 1921–2011*.
Urbánní a regionální laboratoř, Přírodovědecká fakulta Univerzity Karlovy
v Praze, Praha.

- Project and methodology: <https://www.historickygis.cz/cs/o-statistickych-datech>
- Specific judicial-1930 item metadata and usage conditions:
  <https://www.arcgis.com/sharing/rest/content/items/e198e22fc0ed4607bd551596b4738d7b?f=pjson>
- Provider's general metadata:
  <https://www.arcgis.com/sharing/rest/content/items/c2f19cd1146747a9a8daf5b900e7747b?f=json>
- Judicial districts 1930:
  <https://services1.arcgis.com/LPm07959azIAvFRD/ArcGIS/rest/services/Okresy_Ceska_1930/FeatureServer/0>
- Judicial districts 1921:
  <https://services1.arcgis.com/LPm07959azIAvFRD/ArcGIS/rest/services/Okresy_Ceska_1921/FeatureServer/0>
- Official 1930 attribute definitions:
  <https://www.arcgis.com/sharing/rest/content/items/5bd6ad3cebfc4d04a12d9f87c82dfadb/data>
- Official 1921 attribute definitions:
  <https://www.arcgis.com/sharing/rest/content/items/8751f8eaf00347fd8e01d6fd5fc8b315/data>

The provider metadata makes the data freely accessible and requires both
proper citation and acknowledgment of project DF12P01OVV033, the NAKI
programme and the Ministry of Culture of the Czech Republic when publishing
results. Preserve the provider's full Czech project acknowledgment from the
linked `licenseInfo` field when preparing a public release. These custom
conditions are not described here as CC0, MIT or a newly granted data licence.

The period counts refer to the Czech lands, not the entire territory of
interwar Czechoslovakia. The package preserves the inherited historical
limitations; see `METHODS_CZ.md` and the dataset's `docs/AUDIT_CZ.md`.

## CRU-TS v4.10: climate

Required provider attribution: **Climatic Research Unit, University of East
Anglia**. The package uses the dataset's area-weighted district aggregates for
**1901-1938**, from the official CRU-TS v4.10 monthly data.

Harris, I., Osborn, T. J., Jones, P. and Lister, D. (2020). Version 4 of the
CRU TS monthly high-resolution gridded multivariate climate dataset.
*Scientific Data*, 7, 109. <https://doi.org/10.1038/s41597-020-0453-3>

- Variables, units and licence statement: <https://crudata.uea.ac.uk/cru/data/hrg/>
- Version-specific source: <https://crudata.uea.ac.uk/cru/data/hrg/cru_ts_4.10/>
- Open Database License 1.0: <https://opendatacommons.org/licenses/odbl/1-0/>
- Database Contents License: <https://opendatacommons.org/licenses/dbcl/1-0/>

CRU specifies attribution and share-alike conditions. Preserve those conditions
for the climate database component and its applicable derivatives; do not
describe it as public domain or as covered by the package's MIT licence.
The version page did not provide a v4.10-specific DOI at verification; no such
DOI is invented here.

## HydroRIVERS v1.0: river network and district summaries

Lehner, B. and Grill, G. (2013). Global river hydrography and network routing:
baseline data and new approaches to study the world's large river systems.
*Hydrological Processes*, 27(15), 2171-2186.
<https://doi.org/10.1002/hyp.9740>

- Product, citation and licence reference:
  <https://www.hydrosheds.org/products/hydrorivers>
- Official European source archive:
  <https://data.hydrosheds.org/file/HydroRIVERS/HydroRIVERS_v10_eu_shp.zip>
- HydroRIVERS technical definitions:
  <https://data.hydrosheds.org/file/technical-documentation/HydroRIVERS_TechDoc_v10.pdf>
- Applicable HydroSHEDS licence, Appendix A and Exhibit B:
  <https://data.hydrosheds.org/file/technical-documentation/HydroSHEDS_TechDoc_v1_4.pdf>

The provider permits scientific, educational and commercial use subject to
the HydroSHEDS licence. That licence contains attribution and distribution
conditions; free use does not mean unrestricted redistribution under MIT.
For a public derivative distribution, retain the licence and its Exhibit B
notice and review the conditions applicable to the exact materials distributed.
The R package itself reads the user's local data and does not supply a new
standalone mirror of the source river network.

The river-flow attribute is a modelled long-term mean for **1971-2000**. It is
not an observed interwar flow series. The network excludes many small streams.

## Copernicus GLO-90: terrain summaries

The inherited terrain module uses the modern **Copernicus GLO-90 digital
surface model**, aggregated on a 200 m analysis grid. It is not a historical
elevation survey.

- Provider and licensing information:
  <https://dataspace.copernicus.eu/explore-data/data-collections/copernicus-contributing-missions/collections-description/COP-DEM>
- Dataset DOI: <https://doi.org/10.5270/ESA-c5d3d65>
- Provider licence document:
  <https://dataspace.copernicus.eu/sites/default/files/media/files/2025-06/copernicus_contributing_mission_data_access_v2_cop_dem_licenses.pdf>

Required provider notice for adapted or modified WorldDEM-90 data:

> produced using Copernicus WorldDEM-90 © DLR e.V. 2010-2014 and © Airbus Defence and Space GmbH 2014-2018 provided under COPERNICUS by the European Union and ESA; all rights reserved

## Inherited electoral panel

The dataset preserves the earlier project's district election panel and its
crosswalk flags. Its inclusion is not a new transcription of printed election
returns. The documentation currently available to this package does not
establish a complete, separate redistribution licence or the specification of
every inherited model-derived indicator. Public v0.6.1 therefore retains
explicit provenance limitations and module/year-specific publication flags;
it does not assert a new licence over an unidentified original compilation.
Do not interpret inherited `excess_*` indicators without their model
specifications. Brno electoral/census territorial differences and other
identified source problems are documented through `hc_quality_flags()`;
the original counts are preserved.

`hc_elections()` supports the judicial-1930 geography, where the inherited
panel has been linked. Missing records are retained as missing, not treated as
zero votes. Valid-vote counts occur for 1920, 1925, 1929 and 1935 with differing
completeness. They do not supply turnout denominators or full party-level
results for all those years.

## Relationship to RCzechia

This is an independent research package, not an official RCzechia component.
RCzechia already exposes the same URRlab historical boundary/census base via
`historie("okresy_1921")` and `historie("okresy_1930")`:
<https://rczechia.jla-data.net/reference/historie.html>.

The contribution here is access to the integrated and audited v0.5/v0.6/v0.6.1 research
dataset, its environmental extensions, explicit temporal keys and provenance.
Acknowledgment of RCzechia as an interface inspiration does not replace the
citations of the original data providers.


## Additional v0.6 sources

The complete acquisition manifests are part of the GIS release. Their URLs,
file sizes and SHA-256 values are also exposed by `hc_source_files()`. The
original v0.5 manifest remains unchanged; the accessor appends the v0.6 files.

- **Railways:** Ondrej Bedrunka (2023), *Interaktivni mapa vyvoje zeleznicni
  site v Cesku*, Department of Geoinformatics, Palacky University Olomouc.
  <https://dprace.geoinf.upol.cz/dprace/magisterske/bedrunka23/index.html>.
  The original ZIP and thesis are archived. No explicit licence authorising
  public redistribution was found in the ZIP. Public download availability
  is documented; it is not converted into a blanket data licence. The public
  edition supplies recomputed district statistics, not the original network.
  Its correction for Horní Lideč–Púchov uses the verified opening date
  1937-05-02 from Železnice Slovenskej republiky:
  <https://www.zsr.sk/o-nas/historia-zeleznic/1918-1939>. Original source year
  1928 is retained in correction provenance; affected annual states are
  recomputed rather than altered by a blanket length subtraction.
- **SoilGrids:** ISRIC World Soil Information, SoilGrids 2.0.
  <https://soilgrids.org/>. Poggio et al. (2021), SOIL 7, 217-240,
  <https://doi.org/10.5194/soil-7-217-2021>. ISRIC states CC BY 4.0 for these
  products: <https://docs.isric.org/globaldata/soilgrids/SoilGrids_faqs_02.html>.
  Consult the release soil manifest for exact native tiles, units and coverage.
- **HydroBASINS:** HydroSHEDS, v1c Europe, levels 6/8/12.
  <https://www.hydrosheds.org/products/hydrobasins>.
  HydroSHEDS conditions and Lehner and Grill (2013) attribution apply.
- **Geology:** Czech Geological Survey, geological map 1:500,000 (2007),
  official `CGS_Bedrock_Geology/MapServer/2` vector service.
  <https://mapy.geology.cz/arcgis/rest/services/Projekty/CGS_Bedrock_Geology/MapServer/2>.
  Source terms: <https://cgs.gov.cz/en/copyright>. The specific used service
  has no explicit licenceInfo; a separate harmonised INSPIRE service has
  CC BY 4.0, which is not automatically transferred to this source. Public
  outputs are attributed district summaries; original source geometries
  remain with the provider. Map categories and source overlap are documented.
- **State borders:** CShapes 2.0, International Conflict Research, ETH Zurich.
  <https://icr.ethz.ch/data/cshapes/>. Schvitz et al. (2022), *Mapping The
  International System, 1886-2017: The CShapes 2.0 Dataset*, Journal of
  Conflict Resolution 66(1), 144-161. Licence: **CC BY-NC-SA 4.0**.
- **Reference localities:** SOVAMM CZ_RETRO, queried through the NPÚ Geoportal.
  The specific NPÚ source service CP_CZ_Retro_LS/MapServer (Lokalita layer /1)
  states **CC BY-SA 4.0 SOVAMM**:
  <https://geoportal.npu.cz/arcgis/rest/services/CZ_RETRO/CP_CZ_Retro_LS/MapServer/1>.
  The broader SOVAMM author page states **CC BY-NC-SA 4.0**:
  <https://sovamm.wordpress.com/projekty/aktualni-projekty-sovamm/cz_retro/>.
  Both statements are retained. This project does not establish precedence
  or grant new rights to the underlying gazetteer. The public edition
  supplies district summaries/linkages, with original geometry at the
  provider. Records are multitemporal; no 1930 activity is inferred from
  editing timestamps.
- **Spatial relations:** calculated from the unchanged historical district
  polygons. Their original source attribution remains applicable.

The independent source terms, including noncommercial/share-alike conditions
and unresolved rights to redistribute selected original databases, remain
material for reuse. Public v0.6.1 supplies a component-level provenance and
licensing manifest. It does not turn all components into one unrestricted
open database. The R interface does not alter these conditions.


### LUCC land use and contemporary mineral inventory

**LUCC Czechia:** Ivan Bicik, Zbynek Janousek, Jan Kabrda and colleagues,
Faculty of Science, Charles University. *Databaze dlouhodobych zmen vyuziti
ploch Ceska (1845–2000)*, provider documentation 13 March 2015.
Original data and terms:
<https://web.natur.cuni.cz/ksgrrsek/lucc/wp-content/uploads/2017/06/zuj1.zip>
and <https://web.natur.cuni.cz/ksgrrsek/lucc/wp-content/uploads/2017/06/info_zuj.pdf>.
The provider restricts use to **academic/study purposes, without commercial
use, with source citation**. These terms remain separate from the code MIT
licence. Original source-unit totals are area allocated to historical
boundaries. No 1930 interpolation is asserted. The nominal 1845 slice is
based on stable-cadastre material approximately from 1826–1843.

**Mineral inventory:** Czech Geological Survey, contemporary BDPR registries,
retrieved on 2026-11-03 from the official services:
<https://mapy.geology.cz/arcgis/rest/services/Suroviny/loziska_zdroje/MapServer/0>
and
<https://mapy.geology.cz/arcgis/rest/services/Suroviny/Surovinovy_informacni_system/MapServer/13>.
The open B/P/R archive <https://od.geology.cz/loziska_zdroje_ner_sur.zip>
has CC BY 4.0 in its specific catalogue metadata. The added D layer from
SurIS/MapServer/13 is a different source with no confirmed matching open
redistribution licence. CGS attribution and source-data terms apply:
<https://cgs.gov.cz/en/copyright>. The public collection contains derived
district results and provenance; original source geometries remain with the
provider. Contemporary inventory records do not establish interwar mining
activity. Raw category labels, source exclusions and inventory dates remain
in the metadata.
