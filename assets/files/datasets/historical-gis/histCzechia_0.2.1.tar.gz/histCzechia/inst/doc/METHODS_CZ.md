# Jak správně číst data v histCzechia

Balíček zpřístupňuje již vypočtený GIS dataset **v0.5, v0.6 nebo veřejný v0.6.1**, který uživatel připojí
pomocí `hc_use()`. Data zůstávají v jeho místním datovém adresáři. R balíček
nevytváří nové censusové odhady a při běžném načítání nestahuje globální CRU
ani znovu nepočítá říční statistiky. Licence vlastního kódu se nevztahuje
automaticky na převzaté datové komponenty; zdroje uvádí `DATA_SOURCES.md`.

## 1. Geografie a čas

- Hlavní jednotka: **330 soudních okresů roku 1930**. Alternativy: **328
  soudních okresů 1921**, **151 politických okresů 1930** a **151 politických
  okresů 1921**. Rozsah tvoří české země.
- `district_year_id` identifikuje okres i jeho správní geografii. Pro spojování
  používejte tento klíč, nikoli samotný název.
- `boundary_year` označuje rok hranic; `calendar_year` a `month` označují čas
  klimatického pozorování. Klima roku 1910 lze agregovat na hranice roku 1930.
- Censusové údaje opakované v řádcích klimatického panelu zůstávají hodnotami
  svého sčítacího roku. Zopakování censu 1930 v panelu 1901–1938 nevytváří
  každoroční řadu obyvatelstva nebo odvětví.
- Starší censusové údaje připojené podle historických okresů nejsou automaticky
  přepočtené na konstantní hranice 1930. Pro srovnání konkrétních okresů
  kontrolujte dochovaný prostorový crosswalk.
- Politické censusové souhrny zahrnují **plošné odhady**, nikoli nový přepis
  všech politických okresních výsledků. Politická geometrie 1921 navíc
  nepokrývá přibližně **41,538 km²** soudní geografie; není výchozí vrstvou
  pro úplné územní součty.

## 2. Census: definice, které mají význam pro analýzu

Sčítání 1930 se vztahuje k **1. prosinci 1930**, sčítání 1921 k **15. únoru 1921**.
Počty obyvatel jsou převzaté počty přítomného obyvatelstva.

- `b_byt_p` znamená historické **bytové strany**. Nezaměňujte jej automaticky
  za počet fyzických bytů; zkrácený starší alias může být zavádějící.
- `o_nab2_stk` znamená **starokatolické vyznání**. Starší alias v jedné službě
  je chybný; rozhodují oficiální podrobné atributové definice.
- `o_rod` počítá osoby narozené v **obci svého bydliště**, nikoli kdekoli
  v daném okrese.
- `o_nar_csl` a `o_nar2_csl` jsou **československá národnost**. Starší název
  pomocného sloupce `czech` nemění definici původního údaje.
- `o_ek1_bez` a `o_ek2_bez` znamenají **bez uvedeného odvětví povolání**;
  nejsou měrou nezaměstnanosti.
- Průmysl nezahrnuje stavebnictví. Sekundární sektor stavebnictví zahrnuje.
- Podíly `*_active_with_sector` mají ve jmenovateli součet osob zařazených
  do primárního, sekundárního a terciárního sektoru. Podíly
  `*_all_population` mají ve jmenovateli všechny obyvatele.
- Starší `industry`, `agriculture`, `primary` a `secondary` používají
  sektorový jmenovatel. Starší `transport_share_1930` a
  `trade_finance_share_1930` používají celkové obyvatelstvo. Pro srovnávání
  preferujte jednoznačně pojmenované varianty se stejným jmenovatelem.
- Uložená `illiteracy` pochází z roku 1921: počet osob starších pěti let,
  které neuměly číst ani psát, dělený **celkovou populací**. Nejde o
  negramotnost 1930 ani o podíl pouze v populaci starší pěti let.

Zdrojové věkové přiřazení 1921 má známá omezení; součty se mohou v konkrétních
okresech rozcházet. Zůstávají také zdrojové nesrovnalosti u brněnských okresů.
R rozhraní je neopravuje domněnkami. Ověření datových klíčů a aritmetiky
nenahrazuje kontrolu proti dobovým tištěným pramenům.

## 3. Volby

Volební propojení je připraveno pro soudní okresy 1930. Historický panel pokrývá
328 z 330 okresů; Praha-sever a Zlín nejsou připojené. Zachovávají se původní
chybějící hodnoty a příznaky k revizi crosswalku.

- Počty platných hlasů jsou dostupné pro roky 1920, 1925, 1929, 1935 s odlišnou
  úplností; nejde o počty oprávněných voličů ani automaticky o volební účast.
- Pro 1920/1925 panel neposkytuje plné stranické výsledky.
- Podíl SdP mezi všemi platnými hlasy a podíl SdP mezi hlasy německých stran
  mají odlišný jmenovatel.
- Změna podílů vyjádřená v procentních bodech není procentní tempo růstu.
- U některých blokových a modelových ukazatelů není v balíčku úplná původní
  specifikace. Přesné členství stran v blocích ani význam `excess_*`
  nedoplňujte odhadem.

## 4. Terén

Moderní Copernicus GLO-90 je **model povrchu**, který může zahrnovat vegetaci
a stavby. Okresní statistiky vycházejí z 200m pracovní mřížky a středů pixelů
uvnitř polygonu. Výšky jsou v metrech, sklony ve stupních; TRI je zde RMS
výškových rozdílů proti osmi sousedním buňkám, v metrech. Minima a maxima jsou
hodnoty použitého rastru, nikoli geodeticky ověřené nejnižší a nejvyšší body.

## 5. Klima 1901–1938

CRU-TS v4.10 má mřížku **0,5°**. Okresní hodnota je plošně vážený průměr
dotčených buněk, nikoli nové měření uvnitř okresu. V hlavní geografii se používá
60 buněk a 82 okresů leží v jediné buňce. Okresní klimatické řady proto nejsou
330 nezávislými lokálními měřeními; zohledněte sdílené buňky při inferenci.

- Srážky `precip_mm` jsou měsíční nebo roční úhrn podle vybrané frekvence.
- Průměrné teploty jsou ve °C. `temp_mean_daily_min_c` a
  `temp_mean_daily_max_c` jsou průměry denních minim/maxim, nikoli absolutní
  měsíční extrémy.
- PET má měsíční zdrojovou jednotku mm/den; `pet_mm_month` násobí skutečným
  počtem dnů a `pet_mm_year` je roční součet. Roční teplotní průměry jsou
  vážené počtem dnů. Úplný roční souhrn vyžaduje 12 měsíců.
- Vegetační sezona je zde definována jako **duben–září**. Jde o pracovní
  společné období, nikoli model konkrétní plodiny.
- Anomálie a klimatické průměry používají **1901–1928**, tedy 28 let.
  Neoznačujte je za standardní třicetiletý normál WMO. Z-skóre používá
  výběrovou směrodatnou odchylku a nejméně 24 platných základních pozorování.
- Diagnostika `stn` popisuje staniční příspěvky k interpolaci, nejvýše 8;
  není to počet stanic nacházejících se v okrese. PET nemá vlastní STN,
  takže chybějící staniční diagnostika není chybějící hodnota PET.
- `precip_minus_pet_*` je klimatický bilanční rozdíl, nikoli naměřený odtok
  ani automaticky index SPI/SPEI.

## 6. HydroRIVERS

Říční síť je novodobý modelový podklad. `DIS_AV_CMS` a z něj odvozené prahy
používají modelovaný dlouhodobý průtok **1971–2000**, nikoli meziválečné
měření. HydroRIVERS nezachycuje všechny drobné potoky.

- Okresní délka měří pouze části úseků **uvnitř polygonu**. Hustota je
  v km na 100 km². Zdrojové celé úseky zobrazené na mapě mohou přesahovat okres.
- Průtoky navazujících úseků se nesčítají. Největší horní povodí úseku není
  rozlohou okresu ani plochou jeho vnitřního povodí.
- Vzdálenosti jsou přímé mapové vzdálenosti v EPSG:3035, nikoli dopravní
  dostupnost. Centroid a vnitřní referenční bod nejsou automaticky okresním
  městem ani populačním těžištěm.
- Plošné vzdálenosti používají pravidelnou 1km mřížku a nejsou vážené
  obyvatelstvem. Největší vzorkovaná vzdálenost není přesné plošné maximum.
- Úseky na společné hranici mohou přispívat oběma okresům; součet všech
  okresních délek nemusí být unikátní celostátní délkou.
- Z této komponenty samotné neodvozujte historickou splavnost, přístavy,
  povodňové události ani meziválečné průtokové řady.

## 7. Reprodukovatelnost a kontrola

Externí dataset v0.5 uchovává původní historické vstupy, skutečné regionální
zdroje, plošné váhy, skripty, manifesty a kontrolní protokoly. Audit reálného
klimatického a říčního zpracování zaznamenal **410 PASS / 0 FAIL**; tyto kontroly
jsou oddělené od testů R rozhraní. Zdroje a jejich SHA256 jsou zaznamenány
v manifestu. Staré přípravné soubory v0.4 nejsou autoritativními dokončenými
výstupy; pro aktuální data se používá `outputs/wave2_completed/`.

Pro definice polí použijte `hc_dictionary()`, pro prameny `hc_sources()`.
Před věcnou interpretací zachovejte současně jednotku, referenční období,
jmenovatel podílu a příslušnou správní geografii.


## Rozšíření v0.6 a rozhraní 0.2.0

Nové tematické funkce čtou již vypočtené tabulky v0.6. Původní dataset v0.5
zůstává podporovaný a žádná chybějící nová pozorování se nedoplňují odhadem.
`hc_dictionary()` používá slovník připojeného v0.6 GeoPackage; starý slovník
slouží pro v0.5 a pro prohlížení bez připojení dat.

`hc_railways()` rozlišuje kalendářní roky 1901–1938 od roku okresních hranic.
Otevření platí od uvedeného roku včetně; uzavření/zrušení ukončuje platnost
před tímto rokem. U elektrifikace platí obdobné intervaly. Délky jsou délky
sjednocených linií uvnitř okresu. Neznámé geometrie se nevytvářejí a příznaky
chybějících úseků zůstávají v datech. `hc_rail_network()` poskytuje zdrojové
úseky, nikoli stanice nebo cestovní síť s jízdními dobami.

Půda je současný model SoilGrids s hloubkovými intervaly, povodí moderní
HydroBASINS úrovní 6/8/12 a geologie moderní mapa ČGS 1 : 500 000.
Geologické podíly používají jednoznačné plochy původních LEG kategorií;
rozporné překryvy se vykazují zvlášť bez přenormování. Zdrojové vazby zachovávají
i hrubé překryvy;
neprovádí se neověřené sloučení do tří širokých horninových tříd.

Státní hranice mají klíč okres × `snapshot_id`, ne pouze okres × rok.
Rok 1938 obsahuje tři referenční data. CShapes popisuje generalizovaný model
celého Československa; neztotožňuje hranici českých zemí se státní hranicí.
Plochy přesného záboru obyvatelstva z těchto generalizovaných hranic nejsou
v tomto modulu odvozovány.

`hc_gazetteer()` zachovává rozlišení mezi referenční lokalitou a sídlem
potvrzeným pro určitý historický rok. Editační data CZ_RETRO nepotvrzují
existenci roku 1930. Při `geometry=TRUE` vrací lokality bodově; okresní
souhrny a ostatní vazební tabulky nesou okresní polygon.

`hc_neighbors()` vrací orientované páry sousedů. Rook kontakt ve zdrojovém
výpočtu vyžaduje společnou hranici delší než 1 m, queen jakýkoli dodaný
kontakt. Váhy se po výběru okresu nepřepočítávají. Přímé vzdálenosti používají
uložený centroid nebo vnitřní bod; žádný z nich není automaticky sídlem úřadu.

Přesný algoritmus, zdrojové kontrolní součty, skutečné rozsahy a záznamy
vyloučené z výpočtů jsou dokumentované v modulech dodaného GIS archivu.


LUCC obsahuje čtyři zdrojové řezy 1845/1948/1990/2000. `hc_landuse()` zachovává
alokaci souhrnů zdrojových jednotek podle plošného překryvu; nekonstruuje
přesné polohy jednotlivých kategorií uvnitř jednotek. Hlavní podíly jsou
potlačené při méně než 95 % platného zdrojového pokrytí. Neprovádí se
interpolace pro rok 1930. Štítek 1845 přibližně zastupuje podklady stabilního
katastru z let 1826–1843. Meziválečný rok se neodvozuje ani z údajů 1948.

`hc_minerals()` používá současnou evidenci ČGS BDPR získanou 2026-11-03.
Počty označují unikátní evidovaná ložiska protínající okres; souhrnná plocha
používá sjednocení polygonů. Kategorie se mohou překrývat. Nejde o seznam
aktivních historických dolů, těžební produkci nebo historickou zaměstnanost.

Ve v0.6 `hc_panel()` připojuje skutečný roční železniční panel klíčem
`district_year_id` + `calendar_year`; statické řezy 1921/1930/1938 nejsou
zaměněny za roční stavy. Ve v0.5 se žádný nový modul nepřipojuje.


## Veřejná edice v0.6.1 a R rozhraní 0.2.1

Veřejná edice obsahuje 4 okresní geometrie a kolekci samostatně popsaných
výzkumných tabulek. Základ soudních okresů 1930 má 444 polí; 18 původních
`clim_normal*` polí je zvlášť v `gis_climate_normals`, dostupných pomocí
`hc_climate_normals()`. Hodnoty a klíče jsou beze změny. Případné spojení je
výslovným analytickým krokem; neodstraňuje podmínky zdrojových komponent.

Původní zdrojové říční/železniční linie a bodové referenční lokality se
v této veřejné edici neposkytují. `hc_hydro()`, `hc_railways()` a
`hc_gazetteer(detail="summary")` poskytují okresní výsledky. Funkce požadující
původní geometrii vysvětlí její nepřítomnost a odkážou k poskytovateli.
Se staršími kompletními daty nadále fungují.

`hc_quality_flags()` čte zvláštní tabulku příznaků podle okresu, modulu a
období. Původní censusové/volební hodnoty nepřepisuje. U Brna je nutné
odlišit soudní censusové jednotky od obecní městské/venkovské geografie
volebních údajů. Novější mapová edice proto dvě brněnské volební jednotky
podržuje k revizi; ze 328 původních přiřazení zobrazuje 326. Platný censusový
počet 146 140 obyvatel soudního okresu Brno-město se nenahrazuje počtem 264 925
obyvatel celé obce. Ostatní konkrétní příznaky jsou popsány samostatně.

Železniční zdrojový záznam UPOL2023-58 Horní Lideč–Púchov byl v analytické
kopii opraven z roku 1928 na doložené otevření 1937-05-02. Výpočet pro
1928–1937 znovu používá úplnou dostupnou síť pro všechny okresy a 4 geografie,
sjednocení/ořez linií i nejbližší vzdálenosti. Rok 1937 mění pouze přiřazení
otevírací události. Kontrolní stavy 1921/1938 se nemění. Provenience uchovává
původní hodnotu; nejde o úplný nový audit všech železničních chronologií.
Doložení: https://www.zsr.sk/o-nas/historia-zeleznic/1918-1939 .

Podpora CRU vyjádřená plošným podílem 1 znamená 100 % vah s danou podporou,
nikoli jednu lokální stanici. FRS je odvozená proměnná mrazových dnů s
převzatou diagnostikou DTR. Základní metodické a prostorové limity trvají.
Neúplné půdní pokrytí a chybějící časové řezy LUCC zůstávají explicitní;
mapové masky nenahrazují původní coverage pole.
