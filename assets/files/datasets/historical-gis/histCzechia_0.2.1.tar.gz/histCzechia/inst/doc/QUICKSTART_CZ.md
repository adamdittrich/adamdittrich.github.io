# histCzechia 0.2.1 — český návod

Balíček zpřístupňuje náš historický GIS dataset přímo v R. Čte veřejnou
výzkumnou edici **v0.6.1** i původní **v0.6/v0.5**. Hlavní geografií je **330 soudních okresů 1930**;
k dispozici jsou také soudní okresy 1921 a politické okresy 1921/1930.
Územním rozsahem jsou české země. Každá proměnná si zachovává vlastní časové
vymezení; rok okresních hranic sám o sobě neurčuje stáří všech připojených dat.

## Instalace a připojení dat

```r
install.packages(c("sf", "DBI", "RSQLite", "digest"))
base <- "https://adamdittrich.github.io/assets/files/datasets/historical-gis/"
download.file(paste0(base, "histCzechia_0.2.1.tar.gz"),
              "histCzechia_0.2.1.tar.gz", mode = "wb")
install.packages("histCzechia_0.2.1.tar.gz", repos = NULL, type = "source")
download.file(paste0(base, "GIS_Czech_Lands_Public_v0_6_1.zip"),
              "GIS_Czech_Lands_Public_v0_6_1.zip", mode = "wb")
library(histCzechia)

hc_use("GIS_Czech_Lands_Public_v0_6_1.zip",
       cache_dir = tools::R_user_dir("histCzechia", "data"))
hc_data_status()
```

Balíček přijme také dodaný ZIP nebo rozbalenou složku. Soubor lze vybrat přes
`hc_use(file.choose())`. Ze ZIPu rozbalí jen hlavní GeoPackage. Výchozí
`verify = TRUE` ověřuje SHA-256 proti katalogu skutečných vydaných verzí;
prověřuje také základní tabulky a okresní identifikátory. Více rozpoznaných
GeoPackage souborů v jednom ZIPu/složce vyvolá chybu. Přesná cesta k souboru
tuto nejednoznačnost odstraní.

```r
hc_use("cesta/k/dodanemu_archivu.zip",
       cache_dir = tools::R_user_dir("histCzechia", "data"))

# Původní dataset zůstává podporovaný:
# hc_use("historical_gis_czech_lands_v05.gpkg")
```

Bez `cache_dir` je rozbalený soubor uložen jen pro relaci R. V nové relaci
znovu zavolejte `hc_use()`, případně nastavte `HISTCZECHIA_DATA` na přímo
existující GeoPackage. Data se otevírají pouze pro čtení. Dotazy po připojení
fungují offline. R balíček neobsahuje velké zdrojové databáze a nestahuje je.

Jde o lokální zdrojovou distribuci; balíček zatím není na CRAN. Jeho vlastní
kód je čisté R. Závislost `sf` na Linuxu vyžaduje standardní knihovny
GDAL/GEOS/PROJ; na Windows/macOS použijte dostupné binární balíčky závislostí.

## Veřejná edice: 444 základních polí a 18 klimatických polí

Původní master v0.6 obsahuje 462 polí. Veřejná edice zpřístupňuje **444 polí**
v `hc_districts()` a stejných **18 klimatických polí** zvlášť přes
`hc_climate_normals()`. Jde o samostatnou datovou komponentu CRU s licencí
ODbL; žádné původní klimatické hodnoty se neztrácejí. Pro vlastní analýzu
lze tabulky výslovně spojit stabilním identifikátorem:

```r
zaklad <- hc_districts(geometry = FALSE)
normaly <- hc_climate_normals()
pole <- grep("^clim_normal", names(normaly), value = TRUE)
i <- match(zaklad$district_year_id, normaly$district_year_id)
stopifnot(length(pole) == 18L, !anyNA(i),
          !anyDuplicated(normaly$district_year_id))
spojena_tabulka <- cbind(zaklad, normaly[i, pole, drop = FALSE])
# 330 řádků a všech 462 původních polí.
```

Počet polí zahrnuje také identifikátory, diagnostiku a alternativní definice;
neznamená 462 nezávislých kompletních historických pozorování. Další šíření
spojené databáze se nadále řídí podmínkami všech použitých komponent.

Veřejný GeoPackage obsahuje okresní geometrie a vypočtené výsledky. Původní
zdrojové říční/železniční linie a bodové lokality odkazuje u poskytovatelů.
`hc_rivers()`, `hc_rail_network()` a `hc_gazetteer(detail="localities")`
proto v této edici vracejí vysvětlující chybu s dostupnou alternativou;
nevracejí předstíranou prázdnou síť. Se staršími kompletními soubory nadále
fungují. Pro okresní výsledky používejte `hc_hydro()`, `hc_railways()` a
`hc_gazetteer(detail="summary")`.

## Semily: konkrétní příklad

```r
semily <- hc_districts(district = "Semily")
semily[c("NAZEV", "population", "mean_elevation_m", "river_length_km")]
# 17 749 obyvatel při censu 1930, moderní průměrná výška 463,9597 m,
# délka sítě HydroRIVERS uvnitř okresu 31,4020 km.

hc_census(district = "Semily")
hc_elections(district = "Semily")
hc_terrain(district = "Semily")
hc_hydro(district = "Semily")

klima <- hc_climate(1930, district = "Semily")
klima[c("calendar_year", "temp_mean_c", "precip_mm")]
# Přibližně 6,8507 °C a 1 032,3 mm za rok 1930.

zeleznice <- hc_railways(1930, district = "Semily")
zeleznice[c("calendar_year", "rail_operating_length_km",
            "rail_operating_density_km_per_100km2")]
# 11,8118 km evidovaných provozovaných tras uvnitř okresu;
# 13,0624 km na 100 km2.
```

Všechny uvedené hodnoty pocházejí z reálného datasetu. Pro plain tabulku
použijte `hc_districts(..., geometry = FALSE)`. Pro trvalý identifikátor:

```r
hc_districts(district = "CZ1930-J-30102")
hc_find_district("Semil")
```

Názvy se porovnávají přesně, bez ohledu na velikost písmen a českou
diakritiku. Neznámý nebo nejednoznačný název vyvolá chybu.

## Nové moduly v0.6

| Oblast | Funkce a výběr | Časová interpretace |
|---|---|---|
| Železnice | `hc_railways(years = 1901:1938)` | Rekonstruovaný roční stav podle let otevření a uzavření |
| Zdrojové železniční linie | `hc_rail_network(year = 1930)` | Jen starší edice s původními geometriemi; veřejná edice obsahuje okresní souhrny |
| Půda | `hc_soil(detail = "summary")`; `detail = "depth"` | Současný model SoilGrids; hloubkové intervaly zachovány |
| Využití půdy | `hc_landuse(years = c(1845,1948,1990,2000))` | Plošně alokované odhady ze čtyř zdrojových řezů; žádný rok 1930 |
| Ložiska | `hc_minerals()`; `detail = "categories"` nebo `"links"` | Současná evidence ČGS, stav stažení 2026-11-03 |
| Povodí | `hc_basins(basin_level = c(6,8,12))`; `detail = "links"` | Moderní model HydroBASINS a plošné přiřazení |
| Geologie | `hc_geology()`; `detail = "composition"` | Mapa ČGS 1 : 500 000, původní mapové kategorie |
| Státní hranice | `hc_borders(dates = "1938-10-01")` | Přesné dodané referenční datum v modelu CShapes |
| Sousedé | `hc_neighbors(type = "rook")` nebo `"queen"` | Topologie vybrané historické okresní vrstvy |
| Vzdálenosti okresů | `hc_district_distances(to = "Jilemnice")` | Přímé vzdálenosti geometrických referenčních bodů |
| Referenční sídla | `hc_gazetteer(detail = "summary")` | Multitemporální CZ_RETRO; existence roku 1930 není potvrzena |

Všechny okresní moduly používají stejné `district_year_id`. Výchozí výběr
znamená všechny soudní okresy roku 1930. Parametry `boundary_year = 1921`
a `level = "political"` mění geografii. Například:

```r
hc_railways(1935, boundary_year = 1921, district = "Semily")
hc_soil(district = "Semily", detail = "depth")
hc_landuse(c(1845, 1948), district = "Semily")
hc_minerals(district = "Semily", detail = "categories")
hc_basins(district = "Semily", basin_level = c(6, 8, 12))
hc_basins(district = "Semily", basin_level = 12, detail = "links")
hc_geology(district = "Semily", detail = "composition")
hc_neighbors(district = "Semily")
hc_district_distances(district = "Semily", to = c("Jilemnice", "Turnov"))
hc_gazetteer(district = "Semily", detail = "summary", geometry = TRUE)
```

Nové funkce standardně vracejí `data.frame`. `geometry = TRUE` přidá okresní
polygon. Bodové lokality a původní železniční linie vyžadují starší edici,
která je obsahuje. Délky v `hc_railways()` jsou řádně oříznuté na okres.

### Pět řezů státních hranic

```r
hc_borders(district = "Semily")
hc_borders(district = "Semily", dates = c("1938-09-29", "1938-10-01"))
hc_borders(district = "Semily", snapshot_ids = "1938_end")
```

Dostupné dny jsou **1921-01-01, 1930-01-01, 1938-09-29, 1938-10-01 a
1938-12-31**. Rok 1938 má tři různé záznamy. Libovolný jiný den se
neinterpoluje. Nekombinujte současně `dates` a `snapshot_ids`.
Model zahrnuje celé Československo; hranice českých zemí se Slovenskem
není vydávána za zahraniční státní hranici.

## Celý profil a původní časové řady

```r
profil <- hc_profile("Semily", climate_years = 1930)
names(profil)
profil$railways
profil$soil_by_depth
profil$landuse
profil$minerals
profil$geology_composition
profil$borders
profil$gazetteer_summary
profil$quality_flags
profil$notes

# Všech 456 měsíců 1901–1938:
hc_climate(frequency = "monthly", district = "Semily")
# Počasí 1935 na hranicích 1921:
hc_climate(1935, boundary_year = 1921, district = "Semily")
hc_climate_normals(district = "Semily")
hc_cru_weights(district = "Semily")
```

`hc_profile()` přidává jen moduly, které připojený soubor skutečně obsahuje.
Při připojení v0.5 vrátí původní censusově-terénní, volební, klimatický a
hydrologický profil. Přímé zavolání chybějícího nového modulu ve v0.5 jasně
vysvětlí, že vyžaduje v0.6.

`hc_panel(1918:1938)` spojuje roční klima se statickým masterem a ve v0.6
přidává skutečné roční stavy železnic podle ID okresu a kalendářního roku. Census,
terén, hydrologie i případné datované statické sloupce si zachovávají vlastní
období; opakováním řádků z nich nevzniknou každoroční pozorování.
Železniční roční panel lze samostatně získat přes `hc_railways()`.
S v0.5 zůstává výstup panelu původní: klima a statický master.

## Slovník, zdroje a ověření

```r
hc_dictionary("o_ek2_s_pr", table = "judicial_1930")
hc_dictionary("rail_operating_length_km", table = "gis_rail_annual")
hc_sources()
hc_source_files()
hc_validate_data()
citation("histCzechia")
```

Ve v0.6 se slovník čte přímo z `gis_variable_dictionary`. S v0.5 nebo bez
připojených dat zůstává dostupný přibalený původní slovník. Sloupce `type`
a `group` mohou být `NA`, pokud je datový slovník neuvádí.
`hc_source_files()` ve v0.6 spojí starý a nový seznam skutečných zdrojových
souborů včetně URL a SHA-256. Zdrojové cesty popisují provenienci; neznamenají,
že po rozbalení samotného GeoPackage jsou všechny původní soubory vedle něj.

## Příznaky kvality a opravy v0.6.1

```r
hc_quality_flags(district = "Semily")
hc_quality_flags(district = c("CZ1930-J-30247", "CZ1930-J-30245"),
                 module = "elections")
hc_quality_flags(district = "CZ1930-J-30294", module = "rail")
```

`hc_quality_flags()` zachovává název modulu, dotčené roky, vysvětlení a zdroj.
Původní censusové a volební hodnoty zůstávají zachované; R rozhraní je
automaticky nemaskuje. Nepřítomnost příznaku sama o sobě nedokazuje kontrolu
proti dobovému tisku. `hc_profile()` přidává poznámky dostupné v připojené edici.

V0.6.1 opravuje otevření úseku Horní Lideč–Púchov ze zdrojového roku 1928
na doložený rok 1937. Dotčené roční železniční ukazatele byly přepočteny
pro všechny okresy a všechny čtyři geografie; chybějící geometrie
Poříčany–Nymburk zůstává výslovně označena. Změny se čtou z dat, neprovádějí
se neviditelně při dotazu v R.

U Brna nelze zaměnit soudní censusový okres s celou obcí použitou v některých
volebních údajích. Platná censusová populace soudního okresu se nenahrazuje
počtem obyvatel celé obce. Volební nesrovnalosti, ekonomické odlehlé hodnoty
Vsetína/Vejprt a rozdíly historických/GIS rozloh mají vlastní příznaky.

## Co zachovat při interpretaci

- CRU má mřížku 0,5°; Semily leží v jediné buňce. Nejde o vlastní místní
  stanici. Referenční průměr projektu je 1901–1928.
- HydroRIVERS používá moderní síť a modelované průtoky 1971–2000. SoilGrids,
  Copernicus a HydroBASINS nejsou meziválečná měření.
- Železniční vzdálenosti jsou k **trati**, nikoli ke stanici. Stav roku
  vychází z let událostí ve zdroji. Chybějící geometrie a možné omezení sítě
  na dnešní Česko mají vlastní příznaky.
- Geologická kompozice používá jednoznačně přiřazené plochy. Rozporné
  překryvy jsou vykázané zvlášť; chybějící ani sporná plocha se nepřenormalizuje.
  Generalizované mapové kategorie nejsou podíly čistých minerálů.
- LUCC obsahuje nominální řezy 1845, 1948, 1990 a 2000. Souhrny zdrojových
  územních jednotek se plošně rozdělují, neznáme z nich přesnou polohu lesa
  uvnitř každé jednotky. Rok 1845 vychází přibližně z katastrálních podkladů
  1826–1843. Podíl `farmland` je mezisoučet a nesčítá se znovu s jeho složkami.
  Hlavní podíly se neuvádějí při méně než 95 % platného pokrytí.
- Evidence ložisek je současná. Nepředstavuje počet dolů, zaměstnanost nebo
  objem těžby v roce 1930. Pozdější LUCC řezy a současná evidence nemají být
  vydávány za předmeziválečná pozorování.
- CShapes je generalizovaný státní model. Není vhodný pro přesný výpočet
  obyvatelstva anektovaného na základě drobných polygonových rozdílů.
- Počet bodů CZ_RETRO znamená počet přiřazených referenčních záznamů.
  Z editačních dat databáze se neodvozuje existence sídla v roce 1930.
- Sousedské váhy jsou normalizované za celou geografii; výběr okresu jejich
  jmenovatel nemění. Vzdálenosti bodů nejsou dojezdové časy.
- Politické censusy a přiřazení věku 1921 si zachovávají původní omezení.
  Ekonomické podíly mají různé jmenovatele. `b_byt_p` znamená bytové strany;
  `o_ek*_bez` nezjištěné odvětví, nikoli automaticky nezaměstnanost.

Kód má licenci MIT; datová kolekce nemá jednu společnou licenci.
Klimatická komponenta CRU zachovává ODbL 1.0 a Database Contents License,
CShapes CC BY-NC-SA 4.0 a LUCC vlastní akademické/studijní podmínky.
Konkrétní služba NPÚ uvádí pro CZ_RETRO CC BY-SA 4.0, zatímco autorská
stránka SOVAMM uvádí CC BY-NC-SA 4.0; dokumentace uchovává tento rozpor.
Původní UPOL železniční databázi ani vybrané nejasně licencované zdroje ČGS
veřejná edice znovu neposkytuje jako celé geometrické databáze. Uvádí vlastní
okresní výpočty, původ a odkazy na poskytovatele. Podmínky ostatních modulů
nepřenášejte automaticky na nezávislou klimatickou komponentu.
Podrobnosti jsou v manifestu veřejné edice a v instalovaných metodách a zdrojích:

```r
system.file("doc", "METHODS_CZ.md", package = "histCzechia")
system.file("doc", "DATA_SOURCES.md", package = "histCzechia")
system.file("examples", "semily.R", package = "histCzechia")
```
