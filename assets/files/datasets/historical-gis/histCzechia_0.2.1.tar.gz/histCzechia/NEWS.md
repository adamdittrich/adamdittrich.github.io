# histCzechia 0.2.1

- Supports the public research data edition v0.6.1 while retaining the pinned
  v0.5 and v0.6 releases and their existing accessors.
- Makes upstream river, railway and locality geometries optional. Accessors
  for omitted source geometry explain the available district summary and
  original provider; they never substitute an empty historical network.
- Adds `hc_quality_flags()` and includes publication qualifications in
  `hc_profile()`. These notes preserve original census/election values and
  distinguish unresolved observations from documented corrections.
- Documents the public edition's 444 core district fields plus 18 separately
  accessible climate-normal fields and their explicit stable-ID join.
- Reads the corrected railway aggregates for UPOL2023-58, whose verified
  opening is 1937 rather than 1928. The data release recomputes all districts
  for affected years; this package performs no on-read chronology rewriting.
- Documents the CZ_RETRO licence conflict (specific NPÚ service CC BY-SA 4.0;
  broader SOVAMM author page CC BY-NC-SA 4.0) without establishing precedence.
  Preserves distinct source terms for climate and independent components.
- Adapts the executable Semily example to public data without raw source
  lines/points and adds opt-in integration checks for the public release.

# histCzechia 0.2.0

- Adds read-only access to v0.6 railway, soil, LUCC land use, catchment, geology,
  modern mineral inventory, dated state
  border, reference gazetteer, neighbour and pairwise-distance tables.
- Railway calendar years are separate from district boundary years. The
  source network accessor preserves chronology and missing-geometry flags.
- Exact border dates/snapshot IDs preserve three separate observations in
  1938. Gazetteer records retain their multitemporal reference status.
- Reads the v0.6 field dictionary from the connected GeoPackage and combines
  the two source-file manifests without changing the original v0.5 catalogue.
- Supports pinned v0.5 and v0.6 SHA-256 checks. Original v0.5 accessors and
  profile behaviour remain available; absent extension modules fail clearly.
- Joins actual year-specific railway observations into the v0.6 annual panel
  with checked district-year keys; leaves the v0.5 panel unchanged.
- Extends the Semily example, Czech guide and opt-in tests against real data.

# histCzechia 0.1.0

- Initial installable interface to historical GIS dataset v0.5.
- Four fixed historical geographies: judicial and political, 1921 and 1930.
- Full static master, thematic census/terrain/election accessors, monthly and
  annual climate, project climate normals, CRU area weights, hydro metrics,
  clipped river geometries, and annual joined panels.
- Exact-name and stable-ID selectors, including Czech diacritic normalization.
- Read-only GeoPackage queries; explicit local ZIP import with SHA-256 checking.
- Field dictionary, source catalogue, Czech guide and executable Semily example.
- Independent tests against the real dataset; research-data tests opt in via
  HISTCZECHIA_TEST_DATA so installation and ordinary checks need no downloads.

The initial releases were local source-package distributions. The package
has not been submitted to CRAN; data remain external to the R package.
