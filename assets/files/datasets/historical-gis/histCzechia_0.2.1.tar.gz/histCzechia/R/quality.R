#' Publication qualifications for historical district observations
#'
#' Return the explicit quality flags and correction notes distributed with
#' the public research edition. This accessor does not change source values.
#' @inheritParams hc_districts
#' @param module Optional exact module name(s), for example 'elections'.
#'   NULL returns all flags for the selected districts.
#' @return A data.frame or sf object. Multiple flags may belong to one
#'   district. The source columns, affected years and note are preserved.
#' @details Requires the publication_quality_flags table introduced in the
#'   public v0.6.1 data edition. The absence of a flag is not proof of an
#'   independently verified historical observation. These notes supplement
#'   rather than replace inherited coverage and source-quality fields.
#' @examples
#' \dontrun{
#' hc_quality_flags(district = "Semily")
#' hc_quality_flags(district = "CZ1930-J-30247", module = "elections")
#' hc_quality_flags(district = "CZ1930-J-30294", module = "rail")
#' }
#' @export
hc_quality_flags <- function(boundary_year = 1930, level = "judicial",
                             district = NULL, module = NULL,
                             geometry = FALSE, crs = 4326) {
  .hc_path()
  if (!.hc_has_table("publication_quality_flags"))
    stop("This data release predates the publication_quality_flags table. ",
         "Its inherited source diagnostics remain available in the district and thematic tables.",
         call. = FALSE)
  filters <- list()
  if (!is.null(module)) {
    if (!is.character(module) || !length(module) || anyNA(module) || any(!nzchar(module)))
      stop("module must be NULL or a non-empty character vector.", call. = FALSE)
    filters$module <- module
  }
  .hc_module_table("publication_quality_flags", boundary_year, level, district,
                   geometry, filters, crs)
}
