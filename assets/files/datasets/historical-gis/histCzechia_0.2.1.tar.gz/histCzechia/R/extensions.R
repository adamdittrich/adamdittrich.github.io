#' Historical railway indicators on fixed district boundaries
#' @param years Calendar years, any subset of 1901:1938.
#' @inheritParams hc_districts
#' @return One row per district-calendar year, optionally with repeated district
#'   polygons. Original source diagnostics are preserved.
#' @details Requires v0.6. UPOL railway years are a reconstructed annual state:
#'   reported openings start in their year, closures/removals stop in their year.
#'   Lengths are clipped route lengths, not track counts. Distances are straight
#'   distances to represented tracks in Czechia, not station access or travel
#'   times. One source record has missing geometry; flags and edge diagnostics
#'   remain available. The source's public redistribution licence is unconfirmed.
#' @examples
#' \dontrun{
#' hc_railways(1930, district = "Semily")
#' hc_railways(1918:1938, district = "Semily", boundary_year = 1921)
#' }
#' @export
hc_railways <- function(years = 1930, boundary_year = 1930, level = "judicial",
                        district = NULL, geometry = FALSE, crs = 4326) {
  .hc_module_table("gis_rail_annual", boundary_year, level, district, geometry,
                   filters = list(calendar_year = .hc_years(years)), crs = crs)
}

#' Original railway features operating in a selected year
#' @param year One calendar year in 1901:1938.
#' @param electrified_only Restrict to source-recorded electrified operating lines.
#' @param crs Target coordinate reference system, default EPSG:4326.
#' @return An sf object with complete source geometries and original attributes,
#'   selected by their annual validity. No district clipping is performed.
#' @details Requires v0.6. Uses the same year convention as hc_railways().
#'   Source features with NULL geometry are explicitly excluded. The source
#'   covers Czechia and does not supply station locations or journey times.
#'   Upstream railway geometry is not bundled with the public edition.
#'   Its district indicators remain available through hc_railways().
#' @examples
#' \dontrun{
#' rail <- hc_rail_network(1930)
#' semily <- hc_districts(district = "Semily")
#' local <- sf::st_intersection(sf::st_transform(rail, 3035),
#'                              sf::st_transform(semily["district_year_id"], 3035))
#' }
#' @export
hc_rail_network <- function(year = 1930, electrified_only = FALSE, crs = 4326) {
  year <- .hc_years(year)
  if (length(year) != 1L) stop("year must be a single calendar year.", call. = FALSE)
  .hc_flag(electrified_only, "electrified_only")
  .hc_require_table("gis_rail_annual")
  table <- "rail_source_upol"
  .hc_require_source_geometry(table,
    "Use hc_railways() for the supplied district indicators.",
    "https://dprace.geoinf.upol.cz/dprace/magisterske/bedrunka23/")
  source <- .hc_select(table)
  needed <- c("rail_source_id", "rail_geometry_usable", "rail_opening_year",
              "rail_operating_end_exclusive_year", "rail_electric_start_year", "rail_electric_end_year")
  if (!all(needed %in% names(source))) stop("Unsupported railway source schema.", call. = FALSE)
  keep <- source$rail_geometry_usable == 1L & source$rail_opening_year <= year &
    (is.na(source$rail_operating_end_exclusive_year) | source$rail_operating_end_exclusive_year > year)
  if (electrified_only) keep <- keep & !is.na(source$rail_electric_start_year) &
    source$rail_electric_start_year <= year &
    (is.na(source$rail_electric_end_year) | source$rail_electric_end_year > year)
  out <- .hc_source_records(table, "rail_source_id", source$rail_source_id[keep], geometry = TRUE, crs = crs)
  out$calendar_year <- rep(year, nrow(out))
  out
}

#' Soil properties assigned to historical district polygons
#' @param detail 'summary' for the supplied district summary or 'depth' for
#'   the long table by source property and depth interval.
#' @inheritParams hc_districts
#' @return District soil attributes or property-depth rows, optionally with
#'   historical district polygons. Source units and coverage fields are retained.
#' @details Requires v0.6. SoilGrids is a modern model of soil properties;
#'   its values are not soil measurements from 1921 or 1930. Geometry year
#'   describes the aggregation boundary only. Read hc_dictionary() for the
#'   precise depth, unit conversion and coverage of each field.
#' @examples
#' \dontrun{
#' hc_soil(district = "Semily")
#' hc_soil(district = "Semily", detail = "depth")
#' }
#' @export
hc_soil <- function(boundary_year = 1930, level = "judicial", district = NULL,
                     detail = "summary", geometry = FALSE, crs = 4326) {
  detail <- .hc_choice(detail, c("summary", "depth"), "detail")
  table <- if (detail == "summary") "gis_soil" else "gis_soil_by_depth"
  .hc_module_table(table, boundary_year, level, district, geometry, crs = crs)
}

#' Land-use estimates for the four supplied LUCC dates
#' @param years Nominal source years selected from 1845, 1948, 1990 and 2000.
#' @inheritParams hc_districts
#' @return One row per district and supplied source year, including original
#'   area-allocation, split-unit, source-coverage and usability diagnostics.
#' @details Requires v0.6. Source-unit category totals are allocated to
#'   historical districts in proportion to area overlap. These are district
#'   estimates under a within-unit uniformity assumption, not mapped locations
#'   of forest/fields inside each source unit. The 1845 label is a nominal
#'   historical slice based on stable-cadastre material from approximately
#'   1826-1843. No 1930 value or between-date interpolation is produced.
#'   Farmland is a subtotal and must not be added again to the component shares.
#' @examples
#' \dontrun{
#' hc_landuse(c(1845, 1948), district = "Semily")
#' hc_landuse(1948, boundary_year = 1921, district = "Semily")
#' }
#' @export
hc_landuse <- function(years = c(1845, 1948, 1990, 2000), boundary_year = 1930,
                        level = "judicial", district = NULL, geometry = FALSE, crs = 4326) {
  if (!is.numeric(years) || !length(years) || anyNA(years) ||
      any(!years %in% c(1845, 1948, 1990, 2000)))
    stop("years must select the supplied LUCC dates: 1845, 1948, 1990, 2000. No 1930 value is interpolated.",
         call. = FALSE)
  .hc_module_table("gis_landuse", boundary_year, level, district, geometry,
                   filters = list(calendar_year = sort(unique(as.integer(years)))), crs = crs)
}

#' Catchment membership and area links for historical districts
#' @param basin_level HydroBASINS level(s), selected from 6, 8 and 12.
#' @param detail 'summary' for district-level indicators, or 'links' for the
#'   positive-area district-basin intersections and original basin identifiers.
#' @inheritParams hc_districts
#' @return One row per district-level or district-basin intersection, optionally
#'   carrying the district polygon. geometry never substitutes basin geometry.
#' @details Requires v0.6. HydroBASINS is a modern delineation of drainage
#'   basins. Membership is not an observed historical flow or flood series.
#'   Source network identifiers permit upstream/downstream work, but a regional
#'   spatial subset need not include every downstream basin.
#' @examples
#' \dontrun{
#' hc_basins(district = "Semily", basin_level = 12)
#' hc_basins(district = "Semily", basin_level = 6, detail = "links")
#' }
#' @export
hc_basins <- function(boundary_year = 1930, level = "judicial", district = NULL,
                       basin_level = 12, detail = "summary", geometry = FALSE, crs = 4326) {
  if (!is.numeric(basin_level) || !length(basin_level) || anyNA(basin_level) ||
      any(!basin_level %in% c(6, 8, 12)))
    stop("basin_level must contain values from 6, 8 and 12.", call. = FALSE)
  detail <- .hc_choice(detail, c("summary", "links"), "detail")
  table <- if (detail == "summary") "gis_basins" else "gis_basin_district_links"
  .hc_module_table(table, boundary_year, level, district, geometry,
                   filters = list(hybas_level = sort(unique(as.integer(basin_level)))), crs = crs)
}

#' Geological characteristics of historical district areas
#' @param detail 'summary' for one district record or 'composition' for the
#'   supplied original LEG category area shares.
#' @inheritParams hc_districts
#' @return Geological district indicators or category shares, retaining source
#'   labels, coverage and classification notes. Optional geometry is the district.
#' @details Requires v0.6. Geological mapping is a physical-environment
#'   characteristic. It is not a historical mine inventory, production series,
#'   or evidence that a deposit was known or exploited in 1930. Composition
#'   uses unambiguous LEG-category areas. Ambiguous source overlaps are
#'   reported separately and not renormalised away; raw overlapping polygons
#'   remain in the source and district-link tables.
#' @examples
#' \dontrun{hc_geology(district = "Semily", detail = "composition")}
#' @export
hc_geology <- function(boundary_year = 1930, level = "judicial", district = NULL,
                        detail = "summary", geometry = FALSE, crs = 4326) {
  detail <- .hc_choice(detail, c("summary", "composition"), "detail")
  table <- if (detail == "summary") "gis_geology" else "gis_geology_composition"
  .hc_module_table(table, boundary_year, level, district, geometry, crs = crs)
}

#' Contemporary mineral-deposit inventory on historical district polygons
#' @param detail 'summary' for district indicators, 'categories' for source
#'   category summaries, or 'links' for district-deposit intersections.
#' @inheritParams hc_districts
#' @return District indicators or source-category/deposit links, preserving
#'   inventory dates and registry labels. Optional geometry is the district.
#' @details Requires v0.6. These are contemporary CGS BDPR inventory polygons,
#'   retrieved on 2026-11-03. Their overlay does not establish the presence of
#'   an operating mine, mineral output, employment or knowledge of a deposit
#'   in 1921/1930. Straight distances refer to inventory polygons, not mine
#'   entrances or transport access. Categories can overlap; do not sum category
#'   areas across classification dimensions as disjoint land-cover shares.
#' @examples
#' \dontrun{
#' hc_minerals(district = "Semily")
#' hc_minerals(district = "Semily", detail = "categories")
#' }
#' @export
hc_minerals <- function(boundary_year = 1930, level = "judicial", district = NULL,
                         detail = "summary", geometry = FALSE, crs = 4326) {
  detail <- .hc_choice(detail, c("summary", "categories", "links"), "detail")
  table <- switch(detail, summary = "gis_minerals", categories = "gis_minerals_categories",
                  links = "gis_minerals_district_links")
  .hc_module_table(table, boundary_year, level, district, geometry, crs = crs)
}

#' Dated state-border characteristics on historical district polygons
#' @param dates NULL for all supplied reference dates or a character/Date
#'   vector of exact ISO dates available in the data. Arbitrary dates are not
#'   interpolated. Do not combine dates and snapshot_ids.
#' @param snapshot_ids NULL or exact snapshot identifiers listed in the data.
#' @inheritParams hc_districts
#' @return District-snapshot rows with reference_date and snapshot_id retained.
#'   Multiple snapshots within 1938 remain separate observations.
#' @details Requires v0.6. CShapes boundaries are generalised state models,
#'   not local demarcation surveys. Distances and point-in-state diagnostics
#'   are not precise annexed-area/population estimates. boundary_year is the
#'   fixed district geography, not the date of the state-border snapshot.
#' @examples
#' \dontrun{
#' hc_borders(district = "Semily")
#' hc_borders(district = "Semily", dates = "1930-01-01")
#' }
#' @export
hc_borders <- function(boundary_year = 1930, level = "judicial", district = NULL,
                        dates = NULL, snapshot_ids = NULL, geometry = FALSE, crs = 4326) {
  .hc_require_table("gis_borders")
  if (!is.null(dates) && !is.null(snapshot_ids))
    stop("Specify dates or snapshot_ids, not both.", call. = FALSE)
  con <- .hc_connect()
  on.exit(DBI::dbDisconnect(con), add = TRUE)
  available <- DBI::dbGetQuery(con, "SELECT DISTINCT snapshot_id, reference_date FROM gis_borders ORDER BY reference_date")
  filters <- list()
  if (!is.null(dates)) {
    if (inherits(dates, "Date")) dates <- format(dates, "%Y-%m-%d")
    if (!is.character(dates) || !length(dates) || anyNA(dates) ||
        any(!dates %in% available$reference_date))
      stop("dates must be exact supplied reference dates: ",
           paste(available$reference_date, collapse = ", "), ".", call. = FALSE)
    filters$reference_date <- unique(dates)
  }
  if (!is.null(snapshot_ids)) {
    if (!is.character(snapshot_ids) || !length(snapshot_ids) || anyNA(snapshot_ids) ||
        any(!snapshot_ids %in% available$snapshot_id))
      stop("snapshot_ids must be exact supplied IDs: ",
           paste(available$snapshot_id, collapse = ", "), ".", call. = FALSE)
    filters$snapshot_id <- unique(snapshot_ids)
  }
  .hc_module_table("gis_borders", boundary_year, level, district, geometry, filters, crs)
}

#' Spatial neighbours of historical districts
#' @param type 'rook' for positive common boundaries, 'queen' for any supplied
#'   boundary contact. The dataset's topology diagnostics are preserved.
#' @inheritParams hc_districts
#' @return A directed edge table, with district and neighbour IDs and names.
#'   Original row-standardised rook weights refer to the complete geography;
#'   selecting districts does not recompute or renormalise the weights.
#' @details Requires v0.6. Geometry, when requested, repeats the origin
#'   district polygon for each edge. This is a topological relation, not a
#'   transport connection or a causal spillover coefficient.
#' @examples
#' \dontrun{hc_neighbors(district = "Semily", type = "rook")}
#' @export
hc_neighbors <- function(boundary_year = 1930, level = "judicial", district = NULL,
                          type = "rook", geometry = FALSE, crs = 4326) {
  type <- .hc_choice(type, c("rook", "queen"), "type")
  filters <- stats::setNames(list(1L), paste0(type, "_contact"))
  out <- .hc_module_table("gis_neighbors", boundary_year, level, district, geometry, filters, crs)
  registry <- .hc_registry(.hc_geo(boundary_year, level))
  out$neighbor_name <- registry$NAZEV[match(out$neighbor_district_year_id, registry$district_year_id)]
  out
}

#' Pairwise straight distances between historical districts
#' @param to NULL for all destination districts or exact destination names/IDs.
#' @inheritParams hc_districts
#' @return Directed non-self district pairs with centroid and interior-point
#'   distances in kilometres. Optional polygons describe origin districts.
#' @details Requires v0.6. These are geometric distances, not journey times,
#'   network distances or distances between historical district towns.
#' @export
hc_district_distances <- function(boundary_year = 1930, level = "judicial", district = NULL,
                                   to = NULL, geometry = FALSE, crs = 4326) {
  g <- .hc_geo(boundary_year, level)
  filters <- if (is.null(to)) list() else list(neighbor_district_year_id = .hc_ids(g, to))
  out <- .hc_module_table("gis_district_distances", boundary_year, level, district, geometry, filters, crs)
  registry <- .hc_registry(g)
  out$neighbor_name <- registry$NAZEV[match(out$neighbor_district_year_id, registry$district_year_id)]
  out
}

#' Reference gazetteer assigned to historical district polygons
#' @param detail 'localities' for source locality records linked to districts,
#'   or 'summary' for source-record counts. Counts do not measure settlements
#'   known to exist in the boundary year.
#' @inheritParams hc_districts
#' @return For localities, a data frame or sf point object with source metadata
#'   and district-link diagnostics. For summary, district records or polygons.
#' @details Requires v0.6. CZ_RETRO is a multitemporal reference gazetteer.
#'   Modern record-editing dates do not establish historical settlement activity.
#'   Historical existence in 1921 or 1930 is not inferred from spatial overlay.
#'   Ambiguous/outside assignments are retained in the underlying source tables;
#'   a district query returns the records with a matching district link.
#'   When source locality points are not included in the connected public
#'   edition, use detail = 'summary' for district reference counts.
#' @examples
#' \dontrun{
#' hc_gazetteer(district = "Semily")
#' hc_gazetteer(district = "Semily", geometry = TRUE)
#' }
#' @export
hc_gazetteer <- function(boundary_year = 1930, level = "judicial", district = NULL,
                          detail = "localities", geometry = FALSE, crs = 4326) {
  detail <- .hc_choice(detail, c("localities", "summary"), "detail")
  .hc_flag(geometry, "geometry")
  if (detail == "summary")
    return(.hc_module_table("gis_gazetteer_reference", boundary_year, level, district, geometry, crs = crs))
  .hc_require_table("gis_gazetteer_reference")
  .hc_require_source_geometry("cz_retro_localities_reference",
    "Use hc_gazetteer(detail = 'summary') for district reference counts.",
    "https://sovamm.wordpress.com/projekty/aktualni-projekty-sovamm/cz_retro/")
  links <- .hc_module_table("gazetteer_district_links", boundary_year, level, district, FALSE)
  points <- .hc_source_records("cz_retro_localities_reference", "gazetteer_record_id",
                               unique(links$gazetteer_record_id), geometry = geometry, crs = crs)
  attrs <- if (geometry) sf::st_drop_geometry(points) else points
  idx <- match(links$gazetteer_record_id, attrs$gazetteer_record_id)
  if (anyNA(idx) || anyDuplicated(attrs$gazetteer_record_id))
    stop("Gazetteer source keys do not match their district links.", call. = FALSE)
  add <- setdiff(names(attrs), names(links))
  out <- cbind(links, attrs[idx, add, drop = FALSE])
  rownames(out) <- NULL
  if (geometry) out <- sf::st_sf(out, geometry = sf::st_geometry(points)[idx])
  out
}
