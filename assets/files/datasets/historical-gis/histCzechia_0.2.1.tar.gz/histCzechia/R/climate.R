#' Historical monthly or annual climate on fixed district boundaries
#' @param years Calendar years to return, any subset of 1901:1938.
#' @param frequency 'annual' or 'monthly'.
#' @inheritParams hc_districts
#' @return A data.frame (or sf) in long format, with one district-year or
#'   district-month per row. Original climate and diagnostic columns are kept.
#' @details boundary_year and calendar_year describe different dimensions.
#'   CRU-TS v4.10 has a 0.5-degree grid. Annual temperatures are weighted by
#'   days, precipitation is summed. Min/max temperature fields are means of
#'   daily minima/maxima, not absolute extremes. The growing season is April
#'   to September. Anomalies use 1901-1928, not a WMO 30-year normal.
#'   Station counts describe interpolation inputs, not stations in a district.
#'   PET station support is unavailable even when PET values are complete.
#' @examples
#' \dontrun{
#' hc_climate(1930, district = "Semily")
#' hc_climate(1918:1938, "monthly", district = "Semily")
#' }
#' @export
hc_climate <- function(years = 1901:1938, frequency = "annual", boundary_year = 1930,
                       level = "judicial", district = NULL, geometry = FALSE) {
  years <- .hc_years(years)
  if (!is.character(frequency) || length(frequency) != 1L || is.na(frequency) ||
      !frequency %in% c("annual", "monthly"))
    stop("frequency must be 'annual' or 'monthly'.", call. = FALSE)
  .hc_layer_table(paste0("gis_climate_", frequency), boundary_year, level,
                  district, geometry, years)
}

#' Climate means for the project reference period 1901-1928
#' @inheritParams hc_districts
#' @return One row per district with reference-period means and period metadata.
#' @details In the public v0.6.1 edition the 18 clim_normal* fields are
#'   distributed in this separate climate table, rather than repeated in
#'   the static district master. Join them explicitly by district_year_id
#'   when a combined analysis table is needed. The CRU-derived climate
#'   component retains its ODbL and Database Contents License conditions.
#' @examples
#' \dontrun{
#' districts <- hc_districts(geometry = FALSE)
#' normals <- hc_climate_normals()
#' fields <- grep("^clim_normal", names(normals), value = TRUE)
#' idx <- match(districts$district_year_id, normals$district_year_id)
#' stopifnot(!anyNA(idx), !anyDuplicated(normals$district_year_id))
#' combined <- cbind(districts, normals[idx, fields, drop = FALSE])
#' }
#' @export
hc_climate_normals <- function(boundary_year = 1930, level = "judicial",
                               district = NULL, geometry = FALSE) {
  .hc_layer_table("gis_climate_normals", boundary_year, level, district, geometry)
}

#' Area weights linking historical districts to the CRU grid
#' @inheritParams hc_districts
#' @return A data.frame of district-cell intersections, including area_weight.
#'   Weights sum to one within each district.
#' @export
hc_cru_weights <- function(boundary_year = 1930, level = "judicial", district = NULL) {
  .hc_layer_table("gis_cru_area_weights", boundary_year, level, district)
}

#' Annual climate and available railway states with static district attributes
#' @param years Calendar years, any subset of 1901:1938.
#' @inheritParams hc_districts
#' @return One row per district-calendar year. Static fields such as population
#'   are repeated unchanged. Join keys are checked before combining data.
#' @details This is not an annually observed census or electoral panel.
#'   With v0.6, the actual railway state for each calendar year is joined by
#'   district_year_id and calendar_year. v0.5 retains its original climate
#'   and static-master output. Dated static snapshots are not substituted for
#'   the corresponding annual railway state.
#'   boundary_year identifies the fixed geography, while each static variable
#'   retains its documented observation date. geometry = TRUE repeats polygons
#'   across years and may consume substantial memory for the entire country.
#' @examples
#' \dontrun{hc_panel(1929:1935, district = "Semily")}
#' @export
hc_panel <- function(years = 1901:1938, boundary_year = 1930, level = "judicial",
                     district = NULL, geometry = FALSE) {
  .hc_flag(geometry, "geometry")
  weather <- hc_climate(years, "annual", boundary_year, level, district)
  static <- hc_districts(boundary_year, level, district, geometry = FALSE)
  if (anyDuplicated(static$district_year_id)) stop("Static district keys are not unique.", call. = FALSE)
  if (anyDuplicated(weather[c("district_year_id", "calendar_year")]))
    stop("Annual climate keys are not unique.", call. = FALSE)
  idx <- match(weather$district_year_id, static$district_year_id)
  if (anyNA(idx)) stop("Some climate rows have no static district.", call. = FALSE)
  add <- setdiff(names(static), names(weather))
  out <- cbind(weather, static[idx, add, drop = FALSE])
  if (.hc_has_table("gis_rail_annual")) {
    rail <- hc_railways(years, boundary_year, level, district)
    key <- function(x) paste(x$district_year_id, x$calendar_year, sep = "\r")
    if (anyDuplicated(key(rail))) stop("Annual railway keys are not unique.", call. = FALSE)
    ridx <- match(key(out), key(rail))
    if (anyNA(ridx)) stop("Some annual rows have no matching railway state.", call. = FALSE)
    extra <- setdiff(names(rail), names(out))
    out <- cbind(out, rail[ridx, extra, drop = FALSE])
  }
  rownames(out) <- NULL
  if (geometry) out <- .hc_attach_geometry(out, .hc_geo(boundary_year, level))
  attr(out, "static_attributes_notice") <- "Census, elections, terrain and hydro attributes are static and retain their documented reference periods."
  out
}
