#' Historical districts with the complete static research dataset
#'
#' Returns the connected release's master columns and optional sf geometry.
#' All joins use district_year_id. Original field names and missing values
#' are retained; numerical values are not rounded or recomputed.
#'
#' @param boundary_year Year of the district boundaries: 1921 or 1930.
#' @param level Administrative level: 'judicial' or 'political'.
#' @param district NULL for all districts, or exact names/stable IDs. Name
#'   matching ignores case and Czech diacritics; ambiguous names are rejected.
#' @param geometry Return an sf object when TRUE, or a plain data.frame.
#' @param crs Target coordinate reference system for geometry; default EPSG:4326.
#' @return An sf object or data.frame, one row per district. By default this
#'   is 330 judicial districts with all available master columns plus geometry.
#' @details Political census totals are reconstructed from judicial districts;
#'   flags identify fractional spatial estimates versus whole-district sums.
#'   Judicial 1921 age fields carry remapping diagnostics. Legacy election and
#'   census fields inside the 1930 master keep their own observation dates.
#'   Terrain is derived from a modern DSM. Climate normals refer to 1901-1928;
#'   in public v0.6.1 they are held separately by hc_climate_normals().
#'   HydroRIVERS discharge represents modelled 1971-2000 averages.
#' @examples
#' \dontrun{
#' okresy <- hc_districts()
#' semily <- hc_districts(district = "Semily")
#' plot(semily["population"])
#' hc_districts(1921, "political", geometry = FALSE)
#' }
#' @export
hc_districts <- function(boundary_year = 1930, level = "judicial", district = NULL,
                         geometry = TRUE, crs = 4326) {
  .hc_flag(geometry, "geometry")
  g <- .hc_geo(boundary_year, level)
  .hc_sql_query(g, ids = .hc_ids(g, district), geometry = geometry, crs = crs)
}

#' Census attributes on their contemporary historical boundaries
#'
#' Selects census counts, documented ratios and quality flags from the master.
#' Census 1921 remains on 1921 boundaries, census 1930 on 1930 boundaries.
#' This function does not silently harmonize different census years.
#' @inheritParams hc_districts
#' @return An sf object or data.frame containing census fields and identifiers.
#' @details Ratios with suffix active_with_sector use the total of the three
#'   known economic sectors, whereas all_population ratios use all inhabitants.
#'   o_ek1_bez/o_ek2_bez mean no stated occupational branch, not unemployment.
#'   b_byt_p means historical bytove strany, not necessarily physical flats.
#'   Original 1921 age fields and remapping flags are preserved for inspection.
#' @export
hc_census <- function(boundary_year = 1930, level = "judicial", district = NULL,
                      geometry = FALSE, crs = 4326) {
  x <- hc_districts(boundary_year, level, district, geometry = FALSE)
  cols <- grep("^(o_|b_|s_|raw_source_o_|census_|age_|share_|economic_active_|source_settlement_)", names(x), value = TRUE)
  cols <- setdiff(cols, c("share_sample_points_within_1km_river", "share_sample_points_within_5km_river"))
  quality <- c("population", "population_density_gis_km2", "n_contributing_judicial",
               "overlapped_area_km2", "fraction_population_in_split_judicials",
               "smallest_contributing_judicial_share", "n_split_components",
               "boundary_coverage_ratio", "aggregation_class", "is_direct_official_political_census", "is_estimate")
  out <- .hc_subset_columns(x, c(cols, quality))
  .hc_flag(geometry, "geometry")
  if (geometry) out <- .hc_attach_geometry(out, .hc_geo(boundary_year, level), crs)
  out
}

#' Terrain summaries for historical districts
#' @inheritParams hc_districts
#' @return Terrain metrics, identifiers, reference coordinates and analysis flags.
#' @details Modern Copernicus GLO-90 DSM summaries on a 200 m analysis grid.
#'   These are terrain controls, not historical elevation observations.
#' @export
hc_terrain <- function(boundary_year = 1930, level = "judicial", district = NULL,
                       geometry = FALSE, crs = 4326) {
  x <- hc_districts(boundary_year, level, district, geometry = FALSE)
  cols <- grep("elevation|slope|tri_|^terrain_|^analysis_grid|^n_dem|^centroid_|^interior_point_(lon|lat)$|^source_geometry", names(x), value = TRUE)
  out <- .hc_subset_columns(x, cols)
  .hc_flag(geometry, "geometry")
  if (geometry) out <- .hc_attach_geometry(out, .hc_geo(boundary_year, level), crs)
  out
}

#' Electoral panel attached to judicial districts of 1930
#' @param district NULL, exact names or district_year_id values.
#' @param geometry Return sf polygons as well as attributes.
#' @param crs Target coordinate reference system when geometry is TRUE.
#' @return A wide data frame (or sf) with electoral fields and original linkage
#'   flags. All 330 districts are retained; two lack the inherited panel.
#' @details The panel contains valid votes for 1920, 1925, 1929 and 1935,
#'   selected party shares for 1929/1935, and derived German-party indices.
#'   It is not a full set of party results or turnout denominators.
#'   Most shares are fractions; sdp_share_1935_pct is explicitly a percentage.
#'   The exact models underlying the inherited excess_* fields are not fully
#'   documented; those fields are preserved without a new interpretation.
#' @export
hc_elections <- function(district = NULL, geometry = FALSE, crs = 4326) {
  x <- hc_districts(1930, "judicial", district, geometry = FALSE)
  cols <- grep("^valid_votes_|^sdp|^ksc|^german_total_|^right_within_|^left_within_|^cathagr_within_|^henleinization$|^delta_(hhi|enp)$|^german_(hhi|enp)_|^excess_|^crosswalk_any_review|^in_core_panel$|^linked_to_prior", names(x), value = TRUE)
  out <- .hc_subset_columns(x, cols)
  .hc_flag(geometry, "geometry")
  if (geometry) out <- .hc_attach_geometry(out, "judicial_1930", crs)
  out
}
