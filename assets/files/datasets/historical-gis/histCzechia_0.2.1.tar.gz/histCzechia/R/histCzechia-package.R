#' Historical Czech districts with integrated research data
#'
#' A local, read-only interface to historical GIS releases v0.5 and v0.6.
#' Use hc_use() to connect an existing dataset, then hc_districts(),
#' hc_census(), hc_climate(), hc_railways() or hc_profile(). Large data files
#' are external to the package. The package is an independent project,
#' inspired by the function-based interface of RCzechia.
#'
#' @keywords internal
"_PACKAGE"
