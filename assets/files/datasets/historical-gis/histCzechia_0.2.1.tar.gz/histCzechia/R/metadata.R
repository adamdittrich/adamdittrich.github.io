#' Field dictionary and source catalogues
#' @param query Optional literal, case-insensitive substring to search across
#'   field names, descriptions and notes.
#' @param table Optional exact table name(s), e.g. 'judicial_1930',
#'   'gis_climate_annual' or 'gis_rail_annual'.
#' @return hc_dictionary() returns field metadata including units, period,
#'   source and interpretation notes. hc_sources() returns a component-level
#'   attribution catalogue. hc_source_files() returns acquired files and their
#'   recorded SHA-256 hashes from the connected dataset.
#' @details With v0.6 connected, the dictionary is read from the dataset's
#'   gis_variable_dictionary table. The bundled v0.5 dictionary remains available
#'   with v0.5 or no dataset connected. type and group are NA when not supplied
#'   by the v0.6 dictionary; no semantic types are invented.
#'   hc_source_files() preserves the v0.5 schema for v0.5. For v0.6 it appends
#'   the additional source manifest, adding component and path while retaining
#'   filename. Paths are recorded provenance, not guaranteed installed files.
#' @examples
#' hc_dictionary("precip_mm", table = "gis_climate_annual")
#' hc_dictionary("o_ek2_s_pr", table = "judicial_1930")
#' hc_sources()
#' @export
hc_dictionary <- function(query = NULL, table = NULL) {
  if (.hc_has_table("gis_variable_dictionary")) {
    out <- .hc_select("gis_variable_dictionary")
  } else {
    file <- system.file("extdata", "dictionary.csv", package = "histCzechia")
    out <- utils::read.csv(file, stringsAsFactors = FALSE, check.names = FALSE, fileEncoding = "UTF-8")
  }
  standard <- c("table", "variable", "type", "group", "description", "unit", "period", "source", "notes")
  for (name in setdiff(standard, names(out))) out[[name]] <- rep(NA_character_, nrow(out))
  out <- out[, c(standard, setdiff(names(out), standard)), drop = FALSE]
  if (!is.null(table)) {
    if (!is.character(table) || !length(table) || anyNA(table) || any(!table %in% out$table))
      stop("Unknown table. Inspect unique(hc_dictionary()$table).", call. = FALSE)
    out <- out[out$table %in% table, , drop = FALSE]
  }
  if (!is.null(query)) {
    .hc_string(query, "query")
    text <- paste(out$variable, out$description, out$notes)
    out <- out[grepl(.hc_normalize(query), .hc_normalize(text), fixed = TRUE), , drop = FALSE]
  }
  rownames(out) <- NULL
  out
}

#' @rdname hc_dictionary
#' @export
hc_sources <- function() {
  utils::read.csv(system.file("extdata", "sources.csv", package = "histCzechia"),
                  stringsAsFactors = FALSE, fileEncoding = "UTF-8")
}

#' @rdname hc_dictionary
#' @export
hc_source_files <- function() {
  base <- .hc_sql_query("gis_source_catalog")
  if (!.hc_has_table("gis_source_files_v06")) return(base)
  additional <- .hc_select("gis_source_files_v06")
  base$component <- "v05"
  base$path <- base$filename
  if (!"filename" %in% names(additional)) additional$filename <- basename(additional$path)
  fields <- union(names(base), names(additional))
  for (name in setdiff(fields, names(base))) base[[name]] <- NA
  for (name in setdiff(fields, names(additional))) additional[[name]] <- NA
  out <- rbind(base[, fields, drop = FALSE], additional[, fields, drop = FALSE])
  rownames(out) <- NULL
  out
}

#' A complete profile of one historical district
#' @param district One exact name or stable identifier.
#' @param climate_years Calendar years of climate to include, within 1901:1938.
#' @param railway_years Calendar years of railway indicators, defaulting to
#'   climate_years. Used only when the connected release includes railways.
#' @param border_dates NULL for all available dated state-border snapshots,
#'   or exact supplied ISO dates as accepted by hc_borders().
#' @param landuse_years LUCC source years, selected from 1845, 1948, 1990 and
#'   2000. Used only when the connected release contains land-use estimates.
#' @inheritParams hc_districts
#' @return A named list with the original district, census, terrain, elections,
#'   climate, normals, hydro and CRU weights. Available v0.6 modules add railways,
#'   soil, soil_by_depth, basins, basin_links, geology, geology_composition,
#'   borders, neighbors, district_distances, landuse, minerals and gazetteer
#'   tables. Public v0.6.1 additionally exposes publication quality flags.
#'   The list names
#'   make module availability explicit; an older release remains usable.
#'   Reference-period notes are included; no composite score is invented.
#' @examples
#' \dontrun{
#' semily <- hc_profile("Semily", climate_years = 1930)
#' semily$census
#' semily$climate
#' semily$railways
#' }
#' @export
hc_profile <- function(district, boundary_year = 1930, level = "judicial",
                       climate_years = 1901:1938, railway_years = climate_years,
                       border_dates = NULL, landuse_years = c(1845, 1948, 1990, 2000)) {
  g <- .hc_geo(boundary_year, level)
  ids <- .hc_ids(g, district)
  if (length(ids) != 1L) stop("hc_profile() requires exactly one district.", call. = FALSE)
  out <- list(district = hc_districts(boundary_year, level, ids),
              census = hc_census(boundary_year, level, ids),
              terrain = hc_terrain(boundary_year, level, ids),
              elections = if (g == "judicial_1930") hc_elections(ids) else NULL,
              climate = hc_climate(climate_years, boundary_year = boundary_year, level = level, district = ids),
              climate_normals = hc_climate_normals(boundary_year, level, ids),
              hydro = hc_hydro(boundary_year, level, ids),
              cru_weights = hc_cru_weights(boundary_year, level, ids))
  tables <- .hc_tables()
  notes <- c("Census: its own census year and documented historical definitions.",
             "Climate: calendar years 1901-1938 on fixed boundaries; 0.5-degree CRU grid.",
             "Terrain: modern Copernicus DSM.",
             "Hydro: modern river network, modelled discharge reference 1971-2000.",
             "Political census totals are reconstructed; flags identify spatial estimates. 1921 age fields retain remapping caveats.")
  if ("gis_rail_annual" %in% tables) {
    out$railways <- hc_railways(railway_years, boundary_year, level, ids)
    notes <- c(notes, "Rail: reported annual state; source geometry and chronology have exclusions/quality flags; distances are to tracks, not stations.")
  }
  if ("gis_soil" %in% tables) {
    out$soil <- hc_soil(boundary_year, level, ids)
    if ("gis_soil_by_depth" %in% tables) out$soil_by_depth <- hc_soil(boundary_year, level, ids, detail = "depth")
    notes <- c(notes, "Soil: contemporary modelled soil properties by depth, not 1921/1930 measurements.")
  }
  if ("gis_landuse" %in% tables) {
    out$landuse <- hc_landuse(landuse_years, boundary_year, level, ids)
    notes <- c(notes, "Land use: area-allocated source-unit category totals for nominal 1845, 1948, 1990 and 2000; no interpolated 1930 observation.")
  }
  if ("gis_basins" %in% tables) {
    out$basins <- hc_basins(boundary_year, level, ids, basin_level = c(6, 8, 12))
    if ("gis_basin_district_links" %in% tables)
      out$basin_links <- hc_basins(boundary_year, level, ids, basin_level = c(6, 8, 12), detail = "links")
    notes <- c(notes, "Basins: modern terrain-derived drainage units, not historical water management districts.")
  }
  if ("gis_geology" %in% tables) {
    out$geology <- hc_geology(boundary_year, level, ids)
    if ("gis_geology_composition" %in% tables)
      out$geology_composition <- hc_geology(boundary_year, level, ids, detail = "composition")
    notes <- c(notes, "Geology: generalised 1:500,000 bedrock map; composition excludes ambiguous source overlaps without renormalising them away.")
  }
  if ("gis_minerals" %in% tables) {
    out$minerals <- hc_minerals(boundary_year, level, ids)
    if ("gis_minerals_categories" %in% tables)
      out$mineral_categories <- hc_minerals(boundary_year, level, ids, detail = "categories")
    notes <- c(notes, "Minerals: contemporary deposit inventory, retrieved 2026-11-03; no interwar mining activity is asserted.")
  }
  if ("gis_borders" %in% tables) {
    out$borders <- hc_borders(boundary_year, level, ids, dates = border_dates)
    notes <- c(notes, "Borders: exact supplied reference dates of a generalised state-boundary model; multiple 1938 snapshots stay separate.")
  }
  if ("gis_neighbors" %in% tables) out$neighbors <- hc_neighbors(boundary_year, level, ids)
  if ("gis_district_distances" %in% tables)
    out$district_distances <- hc_district_distances(boundary_year, level, ids)
  if ("gis_gazetteer_reference" %in% tables) {
    out$gazetteer_summary <- hc_gazetteer(boundary_year, level, ids, detail = "summary")
    if (all(c("gazetteer_district_links", "cz_retro_localities_reference") %in% tables))
      out$gazetteer <- hc_gazetteer(boundary_year, level, ids)
    notes <- c(notes, "Gazetteer: multitemporal locality reference; counts do not establish settlements active in 1930.")
  }
  if ("publication_quality_flags" %in% tables) {
    out$quality_flags <- hc_quality_flags(boundary_year, level, ids)
    notes <- c(notes, "Publication flags describe unresolved qualifications and documented corrections. Original census and electoral values are preserved; inspect quality_flags before using them.")
  }
  out$notes <- notes
  out
}
