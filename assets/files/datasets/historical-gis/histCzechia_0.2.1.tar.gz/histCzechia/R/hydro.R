#' HydroRIVERS district summaries
#' @inheritParams hc_districts
#' @return One row per district with river lengths, density, distances, modelled
#'   discharge and quality diagnostics. Distances are in km.
#' @details River lengths are clipped to district boundaries. Discharge is a
#'   modelled long-term mean for 1971-2000, not interwar river flow. Distance
#'   summaries refer to geometric points or a 1 km grid, not population centres.
#' @export
hc_hydro <- function(boundary_year = 1930, level = "judicial", district = NULL,
                     geometry = FALSE) {
  .hc_layer_table("gis_hydro", boundary_year, level, district, geometry)
}

#' River geometries intersecting selected historical districts
#' @param district Exact district names or stable IDs. At least one is required
#'   to keep the spatial query explicit; NULL requests the complete selected layer.
#' @inheritParams hc_districts
#' @param clip Clip reaches to each district boundary (default). FALSE returns
#'   complete source reaches with a positive-length overlap, once per reach.
#' @return An sf object. With clip = TRUE, district_year_id and clipped_length_km
#'   identify the segment inside each district. Original LENGTH_KM still refers
#'   to the full source reach. With clip = FALSE, clipped_length_km is omitted.
#' @details Intersections and lengths use EPSG:3035, as in the data pipeline.
#'   Shared-boundary reaches can occur in more than one district. HydroRIVERS
#'   excludes many small streams; discharge is modelled for 1971-2000.
#'   The public research edition omits the upstream regional river layer.
#'   In that edition use hc_hydro() for the supplied district summaries.
#' @examples
#' \dontrun{
#' semily <- hc_districts(district = "Semily")
#' rivers <- hc_rivers("Semily")
#' plot(sf::st_geometry(semily))
#' plot(sf::st_geometry(rivers), col = "steelblue", add = TRUE)
#' }
#' @export
hc_rivers <- function(district, boundary_year = 1930, level = "judicial",
                      clip = TRUE, crs = 4326) {
  .hc_flag(clip, "clip")
  .hc_require_source_geometry("hydrorivers_source_region",
    "Use hc_hydro() for the supplied district river indicators.",
    "https://www.hydrosheds.org/products/hydrorivers")
  shapes <- hc_districts(boundary_year, level, district, geometry = TRUE, crs = 4326)
  # GDAL uses the spatial index to read candidates inside the districts' bbox.
  filter <- sf::st_as_text(sf::st_as_sfc(sf::st_bbox(shapes)))
  rivers <- sf::st_read(.hc_path(), layer = "hydrorivers_source_region",
                        wkt_filter = filter, quiet = TRUE, stringsAsFactors = FALSE)
  rivers_projected <- sf::st_transform(rivers, 3035)
  polygons <- sf::st_transform(shapes[, "district_year_id", drop = FALSE], 3035)
  # Attributes describe the original reach; clipped_length_km is the new metric.
  out <- suppressWarnings(sf::st_intersection(rivers_projected, polygons))
  if (nrow(out)) {
    out <- out[!sf::st_is_empty(out) & sf::st_dimension(out) == 1L, , drop = FALSE]
    out <- suppressWarnings(sf::st_collection_extract(out, "LINESTRING", warn = FALSE))
  }
  out$clipped_length_km <- as.numeric(sf::st_length(out)) / 1000
  out <- out[out$clipped_length_km > 0, , drop = FALSE]
  if (!clip) out <- rivers_projected[rivers_projected$HYRIV_ID %in% out$HYRIV_ID, , drop = FALSE]
  if (!is.null(crs)) out <- sf::st_transform(out, crs)
  rownames(out) <- NULL
  out
}
