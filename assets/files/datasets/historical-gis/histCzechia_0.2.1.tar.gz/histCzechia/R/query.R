.hc_normalize <- function(x) {
  # Explicit Czech transliteration is independent of the system locale.
  x <- chartr("\u00e1\u010d\u010f\u00e9\u011b\u00ed\u0148\u00f3\u0159\u0161\u0165\u00fa\u016f\u00fd\u017e\u00c1\u010c\u010e\u00c9\u011a\u00cd\u0147\u00d3\u0158\u0160\u0164\u00da\u016e\u00dd\u017d",
              "acdeeinorstuuyzACDEEINORSTUUYZ", enc2utf8(x))
  tolower(trimws(x))
}

.hc_registry <- function(geography) {
  con <- .hc_connect()
  on.exit(DBI::dbDisconnect(con), add = TRUE)
  DBI::dbGetQuery(con, paste0("SELECT district_year_id, NAZEV, boundary_year, admin_type, area_gis_km2 FROM ",
                              geography, " ORDER BY district_year_id"))
}

.hc_ids <- function(geography, district = NULL) {
  registry <- .hc_registry(geography)
  if (is.null(district)) return(registry$district_year_id)
  if (!is.character(district) || !length(district) || anyNA(district) || any(!nzchar(trimws(district))))
    stop("district must be NULL or a non-empty character vector of exact names or district_year_id values.", call. = FALSE)
  chosen <- vapply(district, function(d) {
    key <- .hc_normalize(d)
    hit <- which(.hc_normalize(registry$district_year_id) == key)
    if (!length(hit)) hit <- which(.hc_normalize(registry$NAZEV) == key)
    if (!length(hit))
      stop("Unknown district '", d, "' in ", geography, ". Use hc_find_district() to search names.", call. = FALSE)
    if (length(hit) > 1L)
      stop("Ambiguous district '", d, "'; use district_year_id: ",
           paste(registry$district_year_id[hit], collapse = ", "), call. = FALSE)
    registry$district_year_id[hit]
  }, character(1L))
  unique(unname(chosen))
}

.hc_placeholders <- function(n) paste(rep("?", n), collapse = ",")

.hc_sql_query <- function(table, ids = NULL, geography = NULL, years = NULL,
                          geometry = FALSE, crs = 4326) {
  con <- .hc_connect()
  on.exit(DBI::dbDisconnect(con), add = TRUE)
  fields <- DBI::dbListFields(con, table)
  if (!geometry) fields <- setdiff(fields, c("geom", "fid"))
  select <- paste(as.character(DBI::dbQuoteIdentifier(con, fields)), collapse = ", ")
  where <- character()
  params <- list()
  if (!is.null(ids)) {
    where <- c(where, paste0("district_year_id IN (", .hc_placeholders(length(ids)), ")"))
    params <- c(params, as.list(ids))
  }
  if (!is.null(geography)) {
    where <- c(where, "geography = ?")
    params <- c(params, list(geography))
  }
  if (!is.null(years)) {
    where <- c(where, paste0("calendar_year IN (", .hc_placeholders(length(years)), ")"))
    params <- c(params, as.list(years))
  }
  sql <- paste0("SELECT ", select, " FROM ", as.character(DBI::dbQuoteIdentifier(con, table)))
  if (length(where)) sql <- paste(sql, "WHERE", paste(where, collapse = " AND "))
  order <- intersect(c("district_year_id", "calendar_year", "month", "cru_cell_id"), fields)
  if (length(order)) sql <- paste(sql, "ORDER BY", paste(order, collapse = ", "))
  if (!geometry) {
    return(if (length(params)) DBI::dbGetQuery(con, sql, params = params) else DBI::dbGetQuery(con, sql))
  }
  # GDAL's SQL path has no bound parameters. Quote only already-resolved IDs.
  where_sf <- paste0("district_year_id IN (", paste(as.character(DBI::dbQuoteString(con, ids)), collapse = ","), ")")
  sf_sql <- paste0("SELECT district_year_id, geom FROM ", as.character(DBI::dbQuoteIdentifier(con, table)),
                   " WHERE ", where_sf, " ORDER BY district_year_id")
  shapes <- sf::st_read(.hc_path(), query = sf_sql, quiet = TRUE, stringsAsFactors = FALSE)
  # Read attributes through the same DBI path for spatial and plain returns.
  # GDAL otherwise converts BOOLEAN fields to logical while DBI keeps integer.
  attributes <- .hc_sql_query(table, ids, geography, years, geometry = FALSE)
  idx <- match(attributes$district_year_id, shapes$district_year_id)
  if (anyNA(idx) || anyDuplicated(shapes$district_year_id))
    stop("District geometry keys do not match their attributes.", call. = FALSE)
  out <- sf::st_sf(attributes, geometry = sf::st_geometry(shapes)[idx])
  if (!is.null(crs)) out <- sf::st_transform(out, crs = crs)
  out
}

.hc_attach_geometry <- function(x, geography, crs = 4326) {
  if (!"district_year_id" %in% names(x)) stop("Missing district_year_id.", call. = FALSE)
  if (!nrow(x)) return(.hc_empty_spatial(x, geography, crs))
  shapes <- .hc_sql_query(geography, ids = unique(x$district_year_id), geometry = TRUE, crs = crs)
  if (anyDuplicated(shapes$district_year_id)) stop("Duplicate geometry keys.", call. = FALSE)
  idx <- match(x$district_year_id, shapes$district_year_id)
  if (anyNA(idx)) stop("Some observations have no matching district geometry.", call. = FALSE)
  sf::st_sf(x, geometry = sf::st_geometry(shapes)[idx])
}

.hc_empty_spatial <- function(x, table, crs) {
  if (is.null(crs)) {
    con <- .hc_connect()
    on.exit(DBI::dbDisconnect(con), add = TRUE)
    crs <- DBI::dbGetQuery(con,
      "SELECT srs_id FROM gpkg_geometry_columns WHERE table_name = ?", params = list(table))$srs_id
    if (length(crs) != 1L) stop("Cannot determine native geometry CRS.", call. = FALSE)
  }
  sf::st_sf(x, geometry = sf::st_sfc(crs = crs))
}

# Parameterised filters for extension tables. Table/field names are quoted.
.hc_select <- function(table, filters = list(), order = NULL) {
  .hc_require_table(table)
  con <- .hc_connect()
  on.exit(DBI::dbDisconnect(con), add = TRUE)
  fields <- setdiff(DBI::dbListFields(con, table), c("fid", "geom"))
  if (length(filters) && (!length(names(filters)) || any(!names(filters) %in% fields)))
    stop("Unsupported filter schema in ", table, ".", call. = FALSE)
  clauses <- character()
  params <- list()
  for (name in names(filters)) {
    values <- filters[[name]]
    if (is.null(values)) next
    if (!length(values) || anyNA(values)) stop("Filters must be non-empty and non-missing.", call. = FALSE)
    clauses <- c(clauses, paste0(DBI::dbQuoteIdentifier(con, name), " IN (",
                                 .hc_placeholders(length(values)), ")"))
    params <- c(params, as.list(values))
  }
  sql <- paste0("SELECT ", paste(DBI::dbQuoteIdentifier(con, fields), collapse = ","),
                " FROM ", DBI::dbQuoteIdentifier(con, table))
  if (length(clauses)) sql <- paste(sql, "WHERE", paste(clauses, collapse = " AND "))
  order <- intersect(order, fields)
  if (length(order)) sql <- paste(sql, "ORDER BY", paste(DBI::dbQuoteIdentifier(con, order), collapse = ","))
  if (length(params)) DBI::dbGetQuery(con, sql, params = params) else DBI::dbGetQuery(con, sql)
}

.hc_module_table <- function(table, boundary_year, level, district, geometry = FALSE,
                             filters = list(), crs = 4326) {
  .hc_flag(geometry, "geometry")
  .hc_require_table(table)
  geography <- .hc_geo(boundary_year, level)
  ids <- .hc_ids(geography, district)
  filters <- c(list(geography = geography, district_year_id = ids), filters)
  out <- .hc_select(table, filters,
                    c("district_year_id", "calendar_year", "reference_date", "snapshot_id",
                      "hybas_level", "HYBAS_ID", "neighbor_district_year_id", "gazetteer_record_id"))
  registry <- .hc_registry(geography)
  out$NAZEV <- registry$NAZEV[match(out$district_year_id, registry$district_year_id)]
  if (!"boundary_year" %in% names(out)) out$boundary_year <- rep(as.integer(boundary_year), nrow(out))
  if (geometry) out <- .hc_attach_geometry(out, geography, crs)
  out
}

.hc_choice <- function(value, choices, name) {
  if (!is.character(value) || length(value) != 1L || is.na(value) || !value %in% choices)
    stop(name, " must be one of: ", paste(choices, collapse = ", "), ".", call. = FALSE)
  value
}

# Read selected original spatial records using quoted trusted record IDs.
# Literal quoting also avoids SQLite's bound-parameter limit for a full gazetteer.
.hc_source_records <- function(table, key, ids, geometry = FALSE, crs = 4326) {
  .hc_flag(geometry, "geometry")
  .hc_require_table(table)
  con <- .hc_connect()
  on.exit(DBI::dbDisconnect(con), add = TRUE)
  fields <- DBI::dbListFields(con, table)
  if (!key %in% fields || !"geom" %in% fields)
    stop("Unsupported source feature schema in ", table, ".", call. = FALSE)
  condition <- if (!length(ids)) "0=1" else paste0(DBI::dbQuoteIdentifier(con, key), " IN (",
      paste(DBI::dbQuoteString(con, as.character(ids)), collapse = ","), ")")
  attrs <- setdiff(fields, c("fid", "geom"))
  sql <- paste0("SELECT ", paste(DBI::dbQuoteIdentifier(con, attrs), collapse = ","),
                " FROM ", DBI::dbQuoteIdentifier(con, table), " WHERE ", condition,
                " ORDER BY ", DBI::dbQuoteIdentifier(con, key))
  out <- DBI::dbGetQuery(con, sql)
  if (!geometry) return(out)
  if (!nrow(out)) return(.hc_empty_spatial(out, table, crs))
  spatial_sql <- paste0("SELECT ", DBI::dbQuoteIdentifier(con, key), ", geom FROM ",
                        DBI::dbQuoteIdentifier(con, table), " WHERE ", condition)
  shapes <- sf::st_read(.hc_path(), query = spatial_sql, quiet = TRUE)
  idx <- match(out[[key]], shapes[[key]])
  if (anyNA(idx) || anyDuplicated(shapes[[key]])) stop("Source geometry keys are inconsistent.", call. = FALSE)
  answer <- sf::st_sf(out, geometry = sf::st_geometry(shapes)[idx])
  if (!is.null(crs)) answer <- sf::st_transform(answer, crs)
  answer
}

.hc_identity <- c("district_year_id", "NAZEV", "boundary_year", "admin_type", "area_gis_km2")

.hc_subset_columns <- function(x, columns) {
  x[, unique(intersect(c(.hc_identity, columns), names(x))), drop = FALSE]
}

.hc_layer_table <- function(table, boundary_year, level, district, geometry = FALSE, years = NULL) {
  .hc_flag(geometry, "geometry")
  g <- .hc_geo(boundary_year, level)
  ids <- .hc_ids(g, district)
  out <- .hc_sql_query(table, ids = ids, geography = g, years = years)
  registry <- .hc_registry(g)
  out$NAZEV <- registry$NAZEV[match(out$district_year_id, registry$district_year_id)]
  if (!"boundary_year" %in% names(out)) out$boundary_year <- as.integer(boundary_year)
  if (geometry) out <- .hc_attach_geometry(out, g)
  out
}

#' Search historical district names and identifiers
#' @param query Literal substring of a name or identifier. Case and Czech
#'   diacritics are ignored. An empty string lists all districts.
#' @param boundary_year NULL searches both boundary years; otherwise 1921 or 1930.
#' @param level NULL searches both levels; otherwise 'judicial' or 'political'.
#' @return A data frame with stable IDs, names, geography, year and area.
#' @examples
#' \dontrun{hc_find_district("Semil")}
#' @export
hc_find_district <- function(query, boundary_year = NULL, level = NULL) {
  if (!is.character(query) || length(query) != 1L || is.na(query))
    stop("query must be one character string.", call. = FALSE)
  years <- if (is.null(boundary_year)) c(1921, 1930) else boundary_year
  levels <- if (is.null(level)) c("judicial", "political") else level
  geos <- unlist(lapply(levels, function(l) vapply(years, function(y) .hc_geo(y, l), character(1L))))
  ans <- lapply(geos, function(g) {
    z <- .hc_registry(g)
    z$geography <- g
    z
  })
  out <- do.call(rbind, ans)
  key <- .hc_normalize(query)
  keep <- grepl(key, .hc_normalize(out$NAZEV), fixed = TRUE) |
          grepl(key, .hc_normalize(out$district_year_id), fixed = TRUE)
  out <- out[keep, , drop = FALSE]
  rownames(out) <- NULL
  out
}
