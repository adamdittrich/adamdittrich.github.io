# Internal state stores verification metadata only. Research data stay read-only.
.hc_state <- new.env(parent = emptyenv())
.hc_geographies <- c("judicial_1930", "judicial_1921", "political_1930", "political_1921")
.hc_counts <- c(judicial_1930 = 330L, judicial_1921 = 328L,
                political_1930 = 151L, political_1921 = 151L)

.hc_catalog <- function() {
  utils::read.csv(system.file("extdata", "releases.csv", package = "histCzechia"),
                  stringsAsFactors = FALSE, colClasses = "character")
}

.hc_flag <- function(x, name) {
  if (!is.logical(x) || length(x) != 1L || is.na(x))
    stop(name, " must be TRUE or FALSE.", call. = FALSE)
  x
}

.hc_string <- function(x, name) {
  if (!is.character(x) || length(x) != 1L || is.na(x) || !nzchar(x))
    stop(name, " must be one non-empty character string.", call. = FALSE)
  x
}

.hc_geo <- function(boundary_year = 1930, level = "judicial") {
  if (!is.numeric(boundary_year) || length(boundary_year) != 1L ||
      is.na(boundary_year) || !boundary_year %in% c(1921, 1930))
    stop("boundary_year must be 1921 or 1930 (the year of the boundaries).", call. = FALSE)
  if (!is.character(level) || length(level) != 1L || is.na(level) ||
      !level %in% c("judicial", "political"))
    stop("level must be 'judicial' or 'political'.", call. = FALSE)
  paste(level, as.integer(boundary_year), sep = "_")
}

.hc_years <- function(years) {
  if (!is.numeric(years) || !length(years) || anyNA(years) ||
      any(!is.finite(years)) || any(years != as.integer(years)) ||
      any(!years %in% 1901:1938))
    stop("years must contain whole calendar years from 1901 to 1938.", call. = FALSE)
  sort(unique(as.integer(years)))
}

.hc_path <- function() {
  path <- getOption("histCzechia.data", Sys.getenv("HISTCZECHIA_DATA", unset = ""))
  if (!is.character(path) || length(path) != 1L || is.na(path) || !nzchar(path) || !file.exists(path))
    stop("No dataset configured. Run hc_use('/path/to/release.zip') or hc_use('/path/to/release.gpkg').",
         call. = FALSE)
  if (dir.exists(path))
    stop("HISTCZECHIA_DATA must point to the GeoPackage. Use hc_use() for a directory or ZIP.", call. = FALSE)
  normalizePath(path, winslash = "/", mustWork = TRUE)
}

.hc_connect <- function(path = .hc_path()) {
  DBI::dbConnect(RSQLite::SQLite(), dbname = path, flags = RSQLite::SQLITE_RO)
}

.hc_tables <- function(path = .hc_path()) {
  con <- .hc_connect(path)
  on.exit(DBI::dbDisconnect(con), add = TRUE)
  DBI::dbListTables(con)
}

.hc_has_table <- function(table) {
  path <- tryCatch(.hc_path(), error = function(e) NULL)
  if (is.null(path)) return(FALSE)
  table %in% .hc_tables(path)
}

.hc_require_table <- function(table) {
  .hc_path()
  if (!.hc_has_table(table))
    stop("The connected release does not contain '", table,
         "'. This module requires the extended v0.6 dataset; v0.5 remains supported for its original modules.",
         call. = FALSE)
  invisible(TRUE)
}

# Upstream geometries are optional in the public research edition. Their
# omission must not prevent use of district summaries or silently imply
# that absent geometry is an empty historical network.
.hc_require_source_geometry <- function(table, alternative, provider) {
  .hc_path()
  if (!.hc_has_table(table))
    stop("The connected research edition does not include upstream geometry '",
         table, "'. ", alternative, " Source: ", provider,
         ". No empty or reconstructed source geometry has been substituted.",
         call. = FALSE)
  invisible(TRUE)
}

.hc_schema <- function(path) {
  con <- .hc_connect(path)
  on.exit(DBI::dbDisconnect(con), add = TRUE)
  needed <- c(.hc_geographies, "gis_climate_annual", "gis_climate_monthly",
              "gis_climate_normals", "gis_hydro", "gis_cru_area_weights",
              "gis_source_catalog")
  absent <- setdiff(needed, DBI::dbListTables(con))
  if (length(absent))
    stop("Dataset is incomplete; missing original tables: ", paste(absent, collapse = ", "), call. = FALSE)
  for (g in .hc_geographies) {
    if (!all(c("district_year_id", "NAZEV", "boundary_year", "geom") %in% DBI::dbListFields(con, g)))
      stop("Unsupported district schema in ", g, ".", call. = FALSE)
    z <- DBI::dbGetQuery(con, paste0("SELECT COUNT(*) AS n, COUNT(DISTINCT district_year_id) AS u FROM ", g))
    if (z$n != z$u || z$n != .hc_counts[[g]])
      stop("Unexpected or duplicated district keys in ", g, ".", call. = FALSE)
  }
  invisible(TRUE)
}

.hc_check_release <- function(path) {
  checksum <- digest::digest(file = path, algo = "sha256", serialize = FALSE)
  catalog <- .hc_catalog()
  hit <- which(!is.na(catalog$sha256) & catalog$sha256 == checksum)
  if (length(hit) != 1L)
    stop("GeoPackage SHA-256 does not match a pinned data release. ",
         "Use the original supplied dataset, or verify = FALSE only for an intentional local modification.",
         call. = FALSE)
  catalog[hit, , drop = FALSE]
}

.hc_named_version <- function(path) {
  catalog <- .hc_catalog()
  hit <- match(basename(path), catalog$filename)
  if (!is.na(hit)) return(catalog$version[hit])
  con <- .hc_connect(path)
  on.exit(DBI::dbDisconnect(con), add = TRUE)
  if ("gis_release_metadata" %in% DBI::dbListTables(con)) {
    meta <- DBI::dbReadTable(con, "gis_release_metadata")
    if (all(c("key", "value") %in% names(meta))) {
      value <- meta$value[meta$key %in% c("version", "release", "data_version", "release_version")]
      if (length(value)) return(gsub('^"|"$', "", as.character(value[1L])))
    }
  }
  "local-compatible"
}

#' Connect an existing historical GIS data release
#'
#' Connects a supported local v0.5, v0.6 or public v0.6.1 GeoPackage, extracted release
#' directory, or release ZIP. Only the integrated GeoPackage is extracted
#' from a ZIP. Research observations are not bundled or downloaded.
#'
#' @param path Path to the GeoPackage, release directory, or release ZIP.
#' @param cache_dir Directory for ZIP extraction. NULL uses a temporary
#'   session directory. Supply a directory explicitly for persistent caching.
#' @param verify Check SHA-256 against the bundled release catalogue (default
#'   TRUE). FALSE permits an intentional local modification with a compatible
#'   core schema; it does not certify the file as a released dataset.
#' @return The configured absolute GeoPackage path, invisibly. Sets the
#'   session option `histCzechia.data`; does not edit startup files.
#' @details Directories and ZIP files must contain exactly one recognised
#'   integrated GeoPackage name. Multiple candidates are rejected. All files
#'   are opened read-only. ZIP caches are separated by archive checksum.
#'   v0.5 supports the original census, terrain, election, climate and river
#'   functions; requesting an absent v0.6 module gives an explicit error.
#'   The public v0.6.1 edition retains district aggregates while omitting
#'   upstream source geometry. Geometry-specific accessors explain which
#'   summary remains available. Use hc_quality_flags() to inspect publication
#'   qualifications; preserved source observations are not silently masked.
#' @examples
#' \dontrun{
#' hc_use("historical_gis_czech_lands_v061.gpkg")
#' hc_use("GIS_Census_Climate_Hydro_v0_5.zip",
#'        cache_dir = tools::R_user_dir("histCzechia", "data"))
#' hc_districts(district = "Semily")
#' }
#' @export
hc_use <- function(path, cache_dir = NULL, verify = TRUE) {
  .hc_string(path, "path")
  .hc_flag(verify, "verify")
  catalog <- .hc_catalog()
  path <- path.expand(path)
  if (!file.exists(path)) stop("Data path does not exist: ", path, call. = FALSE)
  if (dir.exists(path)) {
    candidates <- list.files(path, recursive = TRUE, full.names = TRUE)
    candidates <- candidates[basename(candidates) %in% catalog$filename]
    if (length(candidates) != 1L)
      stop("Directory must contain exactly one supported integrated GeoPackage; found ",
           length(candidates), ". Supply its exact path.", call. = FALSE)
    path <- candidates[[1L]]
  } else if (grepl("\\.zip$", path, ignore.case = TRUE)) {
    entries <- utils::unzip(path, list = TRUE)
    chosen <- entries$Name[basename(entries$Name) %in% catalog$filename]
    if (length(chosen) != 1L)
      stop("ZIP must contain exactly one supported integrated GeoPackage.", call. = FALSE)
    parts <- strsplit(gsub("\\\\", "/", chosen), "/", fixed = TRUE)[[1L]]
    if (grepl("^[/\\\\]|^[A-Za-z]:", chosen) || any(parts %in% c("..", "")))
      stop("Unsafe archive member path.", call. = FALSE)
    if (is.null(cache_dir)) cache_dir <- file.path(tempdir(), "histCzechia")
    .hc_string(cache_dir, "cache_dir")
    cache_dir <- path.expand(cache_dir)
    dir.create(cache_dir, showWarnings = FALSE, recursive = TRUE)
    if (!dir.exists(cache_dir)) stop("Cannot create cache_dir.", call. = FALSE)
    archive_key <- digest::digest(file = path, algo = "sha256", serialize = FALSE)
    destination <- file.path(cache_dir, paste0("release-", substr(archive_key, 1L, 16L)))
    cached <- file.path(destination, basename(chosen))
    if (!file.exists(cached)) {
      stage <- tempfile("extract-", tmpdir = cache_dir)
      dir.create(stage)
      on.exit(unlink(stage, recursive = TRUE), add = TRUE)
      utils::unzip(path, files = chosen, exdir = stage, overwrite = FALSE)
      extracted <- file.path(stage, chosen)
      if (!file.exists(extracted) || dir.exists(extracted))
        stop("GeoPackage extraction failed.", call. = FALSE)
      if (verify) .hc_check_release(extracted)
      .hc_schema(extracted)
      dir.create(destination, showWarnings = FALSE)
      if (!file.copy(extracted, cached, overwrite = FALSE) && !file.exists(cached))
        stop("Cannot store the extracted GeoPackage in cache_dir.", call. = FALSE)
    }
    path <- cached
  }
  path <- normalizePath(path, winslash = "/", mustWork = TRUE)
  release <- if (verify) .hc_check_release(path) else NULL
  .hc_schema(path)
  options(histCzechia.data = path)
  .hc_state$verified_path <- if (verify) path else NULL
  .hc_state$verified_size <- if (verify) file.info(path)$size else NULL
  .hc_state$verified_mtime <- if (verify) as.numeric(file.info(path)$mtime) else NULL
  .hc_state$verified_version <- if (verify) release$version[[1L]] else NULL
  invisible(path)
}

#' Inspect or validate the connected data release
#' @param checksum Recompute SHA-256 as well as structural validation.
#' @return `hc_data_status()` returns configuration, actual and supported
#'   data versions, available tables, checksum status, publication flag
#'   availability and available upstream geometry tables. `hc_validate_data()`
#'   returns row counts and comparisons with fixed core expectations; an NA
#'   expected count means the count is reported, not independently prescribed.
#' @details Core v0.5 expectations remain valid for v0.6 and v0.6.1. New modules are
#'   checked for non-null, unique join keys when present. New observations are
#'   never silently substituted when a module is absent from an older release.
#'   The public edition keeps source geometry optional; absence of those
#'   tables does not prevent use of the derived district indicators.
#' @export
hc_data_status <- function() {
  path <- tryCatch(.hc_path(), error = function(e) NULL)
  verified <- !is.null(path) && identical(path, .hc_state$verified_path) &&
    identical(file.info(path)$size, .hc_state$verified_size) &&
    identical(as.numeric(file.info(path)$mtime), .hc_state$verified_mtime)
  catalog <- .hc_catalog()
  version <- if (is.null(path)) NULL else if (verified) .hc_state$verified_version else .hc_named_version(path)
  expected <- if (is.null(version)) NULL else catalog$sha256[match(version, catalog$version)]
  tables <- if (is.null(path)) character() else .hc_tables(path)
  list(package = "histCzechia", package_version = as.character(utils::packageVersion("histCzechia")),
       supported_data_versions = catalog$version, data_version = version,
       expected_data_version = version, configured = !is.null(path), path = path,
       pinned_release_verified = verified, expected_sha256 = expected,
       available_tables = tables,
       publication_quality_flags_available = "publication_quality_flags" %in% tables,
       source_geometry_tables_available = intersect(c("hydrorivers_source_region",
         "rail_source_upol", "cz_retro_localities_reference", "cru_grid_cells"), tables))
}

#' @rdname hc_data_status
#' @export
hc_validate_data <- function(checksum = TRUE) {
  .hc_flag(checksum, "checksum")
  path <- .hc_path()
  .hc_schema(path)
  if (checksum) hc_use(path, verify = TRUE)
  con <- .hc_connect(path)
  on.exit(DBI::dbDisconnect(con), add = TRUE)
  integrity <- DBI::dbGetQuery(con, "PRAGMA quick_check")[[1L]]
  if (!identical(integrity, "ok")) stop("SQLite integrity check failed.", call. = FALSE)
  expected <- c(.hc_counts, gis_climate_monthly = 437760L, gis_climate_annual = 36480L,
                gis_hydro = 960L, gis_climate_normals = 960L, gis_cru_area_weights = 2238L,
                hydrorivers_source_region = 43282L, cru_grid_cells = 60L)
  tables <- DBI::dbGetQuery(con, "SELECT table_name FROM gpkg_contents ORDER BY table_name")$table_name
  if (identical(hc_data_status()$data_version, "0.5")) expected["gis_source_catalog"] <- 41L
  observed <- vapply(tables, function(t) as.integer(DBI::dbGetQuery(con,
    paste0("SELECT COUNT(*) AS n FROM ", DBI::dbQuoteIdentifier(con, t)))$n), integer(1))
  prescribed <- unname(expected[match(tables, names(expected))])
  out <- data.frame(table = tables, expected_rows = prescribed, observed_rows = unname(observed),
                    pass = is.na(prescribed) | unname(observed) == prescribed, stringsAsFactors = FALSE)
  if (!all(out$pass)) stop("Unexpected row counts in: ", paste(out$table[!out$pass], collapse = ", "), call. = FALSE)
  keys <- list(gis_rail_annual = c("geography", "district_year_id", "calendar_year"),
               gis_landuse = c("geography", "district_year_id", "calendar_year"),
               gis_soil = c("geography", "district_year_id"),
               gis_geology = c("geography", "district_year_id"),
               gis_minerals = c("geography", "district_year_id"),
               gis_soil_by_depth = c("geography", "district_year_id", "property", "depth_top_cm", "depth_bottom_cm"),
               gis_basins = c("geography", "district_year_id", "hybas_level"),
               gis_borders = c("geography", "district_year_id", "snapshot_id"),
               gis_neighbors = c("geography", "district_year_id", "neighbor_district_year_id"),
               gis_district_distances = c("geography", "district_year_id", "neighbor_district_year_id"))
  for (table in intersect(names(keys), tables)) {
    fields <- keys[[table]]
    if (!all(fields %in% DBI::dbListFields(con, table)))
      stop("Unsupported key schema in ", table, ".", call. = FALSE)
    q <- as.character(DBI::dbQuoteIdentifier(con, fields))
    null_sql <- paste0("SELECT 1 FROM ", DBI::dbQuoteIdentifier(con, table),
                       " WHERE ", paste(paste(q, "IS NULL"), collapse = " OR "), " LIMIT 1")
    dup_sql <- paste0("SELECT 1 FROM ", DBI::dbQuoteIdentifier(con, table),
                      " GROUP BY ", paste(q, collapse = ","), " HAVING COUNT(*) > 1 LIMIT 1")
    if (nrow(DBI::dbGetQuery(con, null_sql)) || nrow(DBI::dbGetQuery(con, dup_sql)))
      stop("Missing or duplicated join keys in ", table, ".", call. = FALSE)
  }
  out
}
