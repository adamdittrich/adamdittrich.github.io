library(testthat)
library(histCzechia)

test_check("histCzechia")
