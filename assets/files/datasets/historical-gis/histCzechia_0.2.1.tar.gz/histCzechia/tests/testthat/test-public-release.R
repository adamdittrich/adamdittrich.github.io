# These tests read the actual public data edition. No historical observations
# are fabricated, downloaded or modified. Older-release checks remain separate.
use_test_public <- function(.local_envir = parent.frame()) {
  path <- Sys.getenv("HISTCZECHIA_TEST_PUBLIC_DATA", unset = "")
  skip_if(!nzchar(path) || !file.exists(path),
          "Set HISTCZECHIA_TEST_PUBLIC_DATA for the public-edition checks.")
  withr::local_options(list(histCzechia.data = getOption("histCzechia.data")),
                       .local_envir = .local_envir)
  hc_use(path)
  expect_identical(hc_data_status()$data_version, "0.6.1")
  invisible(path)
}

test_that("the public release is pinned and its upstream omissions are explicit", {
  use_test_public()
  status <- hc_data_status()
  expect_true(status$pinned_release_verified)
  expect_true(all(c("0.5", "0.6", "0.6.1") %in% status$supported_data_versions))
  expect_true(status$publication_quality_flags_available)
  expect_false(any(c("hydrorivers_source_region", "rail_source_upol",
                      "cz_retro_localities_reference") %in% status$available_tables))
  expect_error(hc_rivers("Semily"), "hc_hydro")
  expect_error(hc_rail_network(1930), "hc_railways")
  expect_error(hc_gazetteer(district = "Semily"), "summary")
  expect_equal(hc_hydro(district = "Semily")$river_length_km,
               31.4019885, tolerance = 1e-8)
  locality_summary <- hc_gazetteer(district = "Semily", detail = "summary")
  expect_equal(locality_summary$gazetteer_reference_record_count, 98)
  expect_true(all(hc_validate_data()$pass))
})

test_that("public climate normals reconstruct all original fields by stable keys", {
  use_test_public()
  core <- hc_districts(geometry = FALSE)
  normals <- hc_climate_normals()
  fields <- grep("^clim_normal", names(normals), value = TRUE)
  expect_equal(dim(core), c(330L, 444L))
  expect_equal(length(fields), 18L)
  expect_false(any(grepl("^clim_normal", names(core))))
  expect_false(anyDuplicated(normals$district_year_id) > 0L)
  idx <- match(core$district_year_id, normals$district_year_id)
  expect_false(anyNA(idx))
  combined <- cbind(core, normals[idx, fields, drop = FALSE])
  expect_equal(dim(combined), c(330L, 462L))
  expect_equal(combined$population[combined$district_year_id == "CZ1930-J-30102"], 17749)
  # Brno's valid judicial population stays source-preserving despite electoral holds.
  expect_equal(combined$population[combined$district_year_id == "CZ1930-J-30247"], 146140)
  counts <- c(judicial_1930 = 330L, judicial_1921 = 328L,
              political_1930 = 151L, political_1921 = 151L)
  for (g in names(counts)) {
    parts <- strsplit(g, "_", fixed = TRUE)[[1L]]
    x <- hc_climate_normals(as.integer(parts[2L]), parts[1L])
    expect_equal(nrow(x), counts[[g]])
    expect_true(all(x$clim_normal_start_year == 1901))
    expect_true(all(x$clim_normal_end_year == 1928))
  }
  expect_equal(nrow(hc_climate(frequency = "monthly", district = "Semily")), 456)
  annual <- hc_climate(1930, district = "Semily")
  expect_equal(annual$temp_mean_c, 6.85068497, tolerance = 1e-8)
  expect_equal(annual$precip_mm, 1032.30002, tolerance = 1e-8)
})

test_that("public railway chronology reflects the recomputed opening correction", {
  use_test_public()
  id <- "CZ1930-J-30294"
  rail <- hc_railways(c(1921, 1928, 1930, 1936, 1937, 1938), district = id)
  expect_equal(rail$rail_operating_length_km,
               c(15.616315443912416, 39.52584522915884, 39.52584522915884,
                 39.52584522915884, 45.51445720192972, 45.51445720192972),
               tolerance = 1e-8)
  expect_equal(rail$rail_local_source_year_event_count, c(0, 2, 0, 0, 1, 0))
  expect_equal(rail$rail_source_record_count_within_district, c(2, 4, 4, 4, 5, 5))
  master <- hc_districts(district = id, geometry = FALSE)
  expect_equal(master$rail_operating_length_km_1930,
               rail$rail_operating_length_km[rail$calendar_year == 1930])
  panel <- hc_panel(c(1930, 1937), district = id)
  expect_equal(panel$rail_operating_length_km,
               rail$rail_operating_length_km[rail$calendar_year %in% c(1930, 1937)])
  expect_equal(hc_railways(1930, district = "Semily")$rail_operating_length_km,
               11.8117937789565, tolerance = 1e-8)
})

test_that("publication flags and district profiles remain usable without source geometries", {
  use_test_public()
  flags <- hc_quality_flags()
  expect_true(all(c("geography", "district_year_id", "module", "flag_code",
                    "severity", "year_start", "year_end", "note", "source_url") %in% names(flags)))
  expect_true(all(flags$geography == "judicial_1930"))
  expect_false(anyNA(flags$district_year_id))
  brno <- hc_quality_flags(district = c("CZ1930-J-30247", "CZ1930-J-30245"),
                           module = "elections")
  expect_setequal(brno$district_year_id, c("CZ1930-J-30247", "CZ1930-J-30245"))
  expect_true(all(brno$module == "elections"))
  spatial <- hc_quality_flags(district = "CZ1930-J-30247", geometry = TRUE)
  expect_s3_class(spatial, "sf")
  expect_identical(sf::st_drop_geometry(spatial), hc_quality_flags(district = "CZ1930-J-30247"))
  profile <- hc_profile("Semily", climate_years = 1930)
  expect_true(all(c("district", "climate", "climate_normals", "hydro", "railways",
                    "soil", "landuse", "minerals", "basins", "geology", "borders",
                    "neighbors", "gazetteer_summary", "quality_flags") %in% names(profile)))
  expect_false("gazetteer" %in% names(profile))
  expect_equal(nrow(profile$climate), 1)
  expect_equal(nrow(profile$borders), 5)
})
