test_that("all four geographies preserve source population and unique IDs", {
  path <- use_test_release()
  cases <- data.frame(
    level = c("judicial", "judicial", "political", "political"),
    boundary_year = c(1930L, 1921L, 1930L, 1921L),
    expected_rows = c(330L, 328L, 151L, 151L),
    stringsAsFactors = FALSE
  )
  for (i in seq_len(nrow(cases))) {
    case <- cases[i, ]
    actual <- hc_districts(boundary_year = case$boundary_year,
                           level = case$level, geometry = FALSE)
    expect_s3_class(actual, "data.frame")
    expect_false(inherits(actual, "sf"))
    expect_equal(nrow(actual), case$expected_rows)
    expect_identical(anyDuplicated(actual$district_year_id), 0L)
    expect_true(all(actual$boundary_year == case$boundary_year))

    fields <- c("district_year_id", "NAZEV", "population", "o_po",
                "area_gis_km2")
    expected <- read_release_table(path,
      paste(case$level, case$boundary_year, sep = "_"), fields)
    actual <- actual[order(actual$district_year_id), fields, drop = FALSE]
    rownames(actual) <- NULL
    expect_equal(actual, expected, tolerance = 0)
  }
})

test_that("Semily selection preserves the actual 1930 census definitions", {
  use_test_release()
  by_name <- hc_districts(district = "Semily", geometry = FALSE)
  by_id <- hc_districts(district = "CZ1930-J-30102", geometry = FALSE)
  expect_equal(by_name, by_id)
  expect_equal(hc_districts(district = "semily", geometry = FALSE), by_id)
  expect_equal(nrow(by_name), 1L)
  expect_equal(by_name$population, 17749)
  expect_equal(by_name$o_po_m + by_name$o_po_z, by_name$population)
  expect_equal(unname(unlist(by_name[c("o_vek1_c0_", "o_vek1_c15",
                                      "o_vek1_c65", "o_vek1_cn")])),
               c(4031, 12325, 1378, 15))
  expect_equal(by_name$economic_active_with_sector_count, 9105)
  expect_equal(by_name$share_industry_active_with_sector,
               6442 / 9105, tolerance = 1e-12)

  census <- hc_census(district = "Semily")
  expect_false(inherits(census, "sf"))
  expect_equal(census$o_po, 17749)
  expect_equal(census$b_byt_p, 4918)
  expect_equal(census$o_rod, 8831)

  terrain <- hc_terrain(district = "Semily")
  expect_equal(terrain$mean_elevation_m, 463.9597473144531,
               tolerance = 1e-10)
})

test_that("spatial returns preserve attributes and permit reprojection", {
  use_test_release()
  plain <- hc_districts(district = "Semily", geometry = FALSE)
  spatial <- hc_districts(district = "Semily")
  expect_s3_class(spatial, "sf")
  expect_equal(sf::st_crs(spatial)$epsg, 4326L)
  expect_true(all(sf::st_is_valid(spatial)))
  attributes <- sf::st_drop_geometry(spatial)
  attributes <- attributes[, names(plain), drop = FALSE]
  rownames(attributes) <- rownames(plain) <- NULL
  expect_equal(attributes, plain, tolerance = 0)

  projected <- hc_districts(district = "Semily", crs = 3035)
  expect_equal(sf::st_crs(projected)$epsg, 3035L)
  expect_equal(as.numeric(sf::st_area(projected)) / 1e6,
               plain$area_gis_km2, tolerance = 1e-6)
})

test_that("census access retains estimation and source-remapping flags", {
  use_test_release()
  political_1930 <- hc_census(boundary_year = 1930, level = "political")
  political_1921 <- hc_census(boundary_year = 1921, level = "political")
  for (x in list(political_1930, political_1921)) {
    expect_true(all(c("aggregation_class", "is_estimate",
                      "is_direct_official_political_census") %in% names(x)))
    expect_true(all(x$is_direct_official_political_census == 0))
  }
  expect_equal(sum(political_1930$is_estimate), 20)
  expect_equal(sum(political_1921$is_estimate), 8)

  older <- hc_census(boundary_year = 1921, district = "Semily")
  expect_equal(older$age_1921_remapped_by_sex_population, 1)
  expect_equal(older$raw_source_o_vek2_c0_, 3980)
  expect_equal(older$o_vek2_c0_, 4691)
})

test_that("climate years remain separate from the fixed boundary year", {
  use_test_release()
  annual <- hc_climate(district = "Semily")
  expect_equal(nrow(annual), 38L)
  expect_equal(sort(annual$calendar_year), 1901:1938)
  expect_true(all(annual$boundary_year == 1930))
  expect_identical(anyDuplicated(annual[c("district_year_id", "calendar_year")]),
                   0L)

  selected <- hc_climate(district = "Semily", years = c(1930, 1935))
  expect_equal(sort(selected$calendar_year), c(1930L, 1935L))
  expect_true(all(selected$boundary_year == 1930))
  expect_equal(selected$precip_mm[selected$calendar_year == 1930],
               1032.30002, tolerance = 1e-10)
  expect_equal(selected$temp_mean_c[selected$calendar_year == 1930],
               6.85068497, tolerance = 1e-10)

  monthly <- hc_climate(district = "Semily", frequency = "monthly")
  expect_equal(nrow(monthly), 456L)
  expect_true(all(table(monthly$calendar_year) == 12L))
  expect_identical(anyDuplicated(monthly[c("district_year_id", "calendar_year",
                                           "month")]), 0L)
  totals <- aggregate(precip_mm ~ calendar_year, monthly, sum)
  annual <- annual[match(totals$calendar_year, annual$calendar_year), ]
  expect_equal(annual$precip_mm, totals$precip_mm, tolerance = 1e-6)

  older_boundaries <- hc_climate(district = "Semily", boundary_year = 1921,
                                 years = 1935)
  expect_equal(older_boundaries$calendar_year, 1935L)
  expect_equal(older_boundaries$boundary_year, 1921L)
  expect_equal(older_boundaries$district_year_id, "CZ1921-J-21102")
})

test_that("annual panels join once per district-year and retain static census", {
  use_test_release()
  panel <- hc_panel(years = c(1929, 1930, 1935))
  expect_equal(nrow(panel), 330L * 3L)
  expect_identical(anyDuplicated(panel[c("district_year_id", "calendar_year")]),
                   0L)
  semily <- panel[panel$district_year_id == "CZ1930-J-30102", ]
  expect_equal(nrow(semily), 3L)
  expect_true(all(semily$population == 17749))
  expect_true(all(semily$boundary_year == 1930))
  expect_false(any(grepl("\\.[xy]$", names(panel))))

  spatial <- hc_climate(district = "Semily", years = 1930,
                        geometry = TRUE)
  expect_s3_class(spatial, "sf")
  expect_equal(nrow(spatial), 1L)
  expect_equal(spatial$precip_mm, semily$precip_mm[semily$calendar_year == 1930],
               tolerance = 0)
})

test_that("CRU weights and normals retain the Semily single-cell structure", {
  use_test_release()
  weights <- hc_cru_weights(district = "Semily")
  expect_equal(nrow(weights), 1L)
  expect_equal(weights$cru_cell_id, "CRU_50.75_15.25")
  expect_equal(weights$area_weight, 1)

  all_weights <- hc_cru_weights()
  sums <- aggregate(area_weight ~ district_year_id, all_weights, sum)
  expect_equal(nrow(sums), 330L)
  expect_true(all(abs(sums$area_weight - 1) < 1e-9))

  normals <- hc_climate_normals(district = "Semily")
  expect_equal(normals$clim_normal_start_year, 1901L)
  expect_equal(normals$clim_normal_end_year, 1928L)
  expect_equal(normals$clim_normal_n_years, 28L)
  expect_equal(normals$clim_normal_1901_1928_temp_mean_c,
               mean(hc_climate(district = "Semily", years = 1901:1928)$temp_mean_c),
               tolerance = 1e-8)
})

test_that("river geometry is clipped and reproduces the stored Semily length", {
  use_test_release()
  hydro <- hc_hydro(district = "Semily")
  expect_equal(nrow(hydro), 1L)
  expect_equal(hydro$n_hydrorivers_reaches, 11L)
  # The dedicated hydro table preserves its nine-significant-digit export;
  # the static master additionally retains the original higher precision.
  expect_equal(hydro$river_length_km, 31.4019885,
               tolerance = 1e-10)

  rivers <- hc_rivers(district = "Semily", clip = TRUE, crs = 3035)
  expect_s3_class(rivers, "sf")
  expect_equal(sf::st_crs(rivers)$epsg, 3035L)
  expect_true(all(!sf::st_is_empty(rivers)))
  expect_true(all(rivers$clipped_length_km > 0))
  expect_equal(sum(rivers$clipped_length_km), hydro$river_length_km,
               tolerance = 1e-5)
  expect_equal(sum(as.numeric(sf::st_length(rivers))) / 1000,
               hydro$river_length_km, tolerance = 1e-5)
})

test_that("the inherited election panel keeps distinct denominators", {
  use_test_release()
  votes <- hc_elections(district = "Semily")
  expect_equal(nrow(votes), 1L)
  expect_equal(votes$valid_votes_1920, 8997)
  expect_equal(votes$valid_votes_1925, 9965)
  expect_equal(votes$valid_votes_1929, 10490)
  expect_equal(votes$valid_votes_1935, 11238)
  expect_equal(votes$ksc29 * votes$valid_votes_1929, 1265, tolerance = 1e-8)
  expect_equal(votes$ksc35 * votes$valid_votes_1935, 1680, tolerance = 1e-8)
  expect_equal(votes$sdp_share_1935 * votes$valid_votes_1935, 93,
               tolerance = 1e-8)
  expect_equal(votes$sdp_within_1935, 93 / 115, tolerance = 1e-10)
})

test_that("district selectors and time filters reject misleading requests", {
  use_test_release()
  expect_error(hc_districts(district = "Not an actual district"))
  expect_error(hc_districts(district = c("Semily", "Not an actual district")))
  expect_error(hc_districts(boundary_year = 1935))
  expect_error(hc_districts(level = "modern"))
  expect_error(hc_districts(district = "CZ1921-J-21102", boundary_year = 1930))
  expect_error(hc_climate(years = 1900))
  expect_error(hc_climate(years = 1939))
  expect_error(hc_climate(years = 1930.5))
  expect_error(hc_climate(years = c(1930, NA_real_)))

  found <- hc_find_district("semil", boundary_year = 1930, level = "judicial")
  expect_true("CZ1930-J-30102" %in% found$district_year_id)
  expect_equal(hc_districts(district = "Ceska Lipa", geometry = FALSE)$district_year_id,
               "CZ1930-J-30113")
  expect_equal(hc_districts(district = "\u010cesk\u00e1 L\u00edpa", geometry = FALSE)$district_year_id,
               "CZ1930-J-30113")
})

test_that("the supplied release ZIP can be attached and reused from a cache", {
  archive <- Sys.getenv("HISTCZECHIA_TEST_ZIP", unset = "")
  skip_if(!nzchar(archive) || !file.exists(archive),
           "Set HISTCZECHIA_TEST_ZIP to test the optional ZIP import route.")
  withr::local_options(list(histCzechia.data = getOption("histCzechia.data")))
  cache <- withr::local_tempdir()
  first <- suppressMessages(hc_use(archive, cache_dir = cache))
  expect_true(file.exists(first))
  expect_equal(hc_districts(district = "Semily", geometry = FALSE)$population,
               17749)
  second <- suppressMessages(hc_use(archive, cache_dir = cache))
  expect_identical(first, second)
})
