# These integration tests use the actual, separately supplied v0.5 or v0.6 release.
# No historical or climate observations are synthesized for the tests.
use_test_release <- function(.local_envir = parent.frame()) {
  path <- Sys.getenv("HISTCZECHIA_TEST_DATA", unset = "")
  testthat::skip_if(!nzchar(path),
                    "Set HISTCZECHIA_TEST_DATA to a supported GeoPackage.")
  testthat::skip_if(!file.exists(path), "The external release is unavailable.")
  withr::local_options(
    list(histCzechia.data = getOption("histCzechia.data")),
    .local_envir = .local_envir
  )
  suppressMessages(hc_use(path))
  invisible(normalizePath(path, winslash = "/", mustWork = TRUE))
}

read_release_table <- function(path, table, columns) {
  con <- DBI::dbConnect(RSQLite::SQLite(), path, flags = RSQLite::SQLITE_RO)
  on.exit(DBI::dbDisconnect(con), add = TRUE)
  cols <- paste(DBI::dbQuoteIdentifier(con, columns), collapse = ", ")
  sql <- paste("SELECT", cols, "FROM", DBI::dbQuoteIdentifier(con, table),
               "ORDER BY district_year_id")
  DBI::dbGetQuery(con, sql)
}

use_test_v06 <- function() {
  path <- use_test_release(.local_envir = parent.frame())
  testthat::skip_if(!identical(hc_data_status()$data_version, "0.6"),
                    "The v0.6 integration tests require the extended release.")
  invisible(path)
}
